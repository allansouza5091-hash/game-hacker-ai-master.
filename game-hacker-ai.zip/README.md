# GAME HACKER AI MASTER

Aplicativo Android nativo desenvolvido em **Kotlin + Jetpack Compose + Material 3** para importação segura de arquivos APK, inspeção de pacotes instalados em conformidade com o Android, análise técnica estática, detecção diferenciada de referências de variáveis e edição controlada com backup/restauração para jogos próprios ou autorizados.

## Arquitetura do Projeto

```
app/src/main/java/com/example/
├── ai/          # GameAiEngine + motor técnico local (preparado para Firebase AI Logic)
├── analysis/    # Extração SAF/PackageManager, scanner DEX/JSON/recursos, detector de variáveis e limitações online
├── core/        # AppContainer, orquestrador de pipeline em 9 etapas e formatadores
├── data/        # Room Database (DAOs/Entities), DataStore SettingsRepository e repositórios
├── domain/      # Modelos de domínio, enums epistêmicos e UiState
├── feature/     # Telas e ViewModels (home, installed, analysis, editor, history, settings, components)
├── security/    # ApkSecurityValidator (PK/ZipSlip/ZipBomb/SHA-256) e CryptoVaultManager (Android Keystore)
└── ui/theme/    # Tema futurista (Preto profundo, Roxo neon, Azul elétrico, fontes Space Grotesk / Plus Jakarta Sans / JetBrains Mono)
```

## Funcionalidades Implementadas

1. **Painel Inicial (`HomeScreen`)**: Telemetria em tempo real (quantidade de jogos importados, última análise, estado do sistema e do mecanismo de IA) e 6 módulos funcionais.
2. **Importação Real de APK (`ADICIONAR APK`)**: Usa o Android Storage Access Framework (`OpenDocument`), valida cabeçalho `PK`, protege contra ZipSlip e ZIP bombs, calcula SHA-256, extrai nome, pacote, versão, tamanho e ícone via `PackageManager.getPackageArchiveInfo`, salvando na biblioteca persistente Room.
3. **Jogos Instalados (`JOGOS INSTALADOS`)**: Consulta pacotes visíveis respeitando `<queries>` no `AndroidManifest.xml`, classificando Jogos, Aplicativos e Sistema.
4. **Pipeline `GAME AI ENGINE` (`ANALISAR COM IA`)**: Executa 9 etapas reais de inspeção, diferenciando referências nominais em UI (`IDENTIFICADO`), símbolos em `classes*.dex` (`PROVAVEL`) e valores estáticos explícitos em JSON/config (`CONFIRMADO`), além de identificar restrições de jogos online.
   - *Nota sobre IA em Nuvem*: Nesta configuração sem Firebase provisionado, o mecanismo opera em modo técnico local determinístico sem embutir chaves de API no código ou APK.
5. **Editor de Valores Autorizado (`EDITOR DE VALORES`)**: Edição restrita a perfis próprios (`Meu jogo de teste` ou arquivos JSON importados com `authorizedEdit: true`), com validação, diálogo de confirmação, backup automático, histórico de alterações, restauração em 1 toque e exportação JSON via SAF.
6. **Histórico & Configurações (`HISTÓRICO`, `CONFIGURAÇÕES`)**: Reabertura completa de relatórios salvos no Room, controle de limites de segurança via DataStore, cofre criptografado com Android Keystore AES-256-GCM e logs técnicos.

## Compilação do APK e Testes

### Gerar APK de depuração (Debug)

```bash
./gradlew assembleDebug
```

Saída gerada:
```
app/build/outputs/apk/debug/app-debug.apk
```

*(Nota: em ambientes com `gradle` instalado globalmente sem wrapper, execute `gradle assembleDebug`.)*

### Gerar APK/AAB de lançamento assinado (Release)

Configure as variáveis de ambiente `KEYSTORE_PATH`, `STORE_PASSWORD` e `KEY_PASSWORD` (sem versionar senhas no Git) e execute:

```bash
./gradlew assembleRelease
# ou para Play Store App Bundle:
./gradlew bundleRelease
```

### Executar Testes Automatizados (Unitários + Robolectric)

```bash
./gradlew :app:testDebugUnitTest
```

## Publicação no GitHub

O `.gitignore` já exclui caches do Gradle, builds, `.env` locais e arquivos temporários. Antes de enviar ao GitHub:
1. Verifique que nenhum arquivo `.env` ou keystore privado foi adicionado ao staging.
2. Inicialize e envie o repositório normalmente (`git init`, `git add .`, `git commit`, `git push`).
