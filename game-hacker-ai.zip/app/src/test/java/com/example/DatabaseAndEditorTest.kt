package com.example

import android.content.Context
import android.net.Uri
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.analysis.ApkMetadataExtractor
import com.example.data.AnalysisHistoryRepository
import com.example.data.AuthorizedEditorRepository
import com.example.data.EditorValuesInput
import com.example.data.GameLibraryRepository
import com.example.data.db.AuthorizedProfileEntity
import com.example.data.db.GameHackerDatabase
import com.example.domain.AnalysisReport
import com.example.domain.AiInterpretationResult
import com.example.domain.ApkTechnicalMetadata
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class DatabaseAndEditorTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    private lateinit var context: Context
    private lateinit var db: GameHackerDatabase
    private lateinit var editorRepository: AuthorizedEditorRepository
    private lateinit var libraryRepository: GameLibraryRepository
    private lateinit var historyRepository: AnalysisHistoryRepository

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, GameHackerDatabase::class.java)
            .allowMainThreadQueries()
            .build()

        editorRepository = AuthorizedEditorRepository(context, db.authorizedEditorDao(), db.auditLogDao())
        libraryRepository = GameLibraryRepository(
            gameDao = db.gameDao(),
            auditLogDao = db.auditLogDao(),
            metadataExtractor = ApkMetadataExtractor(context)
        )
        historyRepository = AnalysisHistoryRepository(db.analysisHistoryDao())
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `authorized editor creates default profile, applies changes with backup, and restores snapshot`() = runTest {
        editorRepository.ensureDefaultAuthorizedProfile()
        val profiles = editorRepository.profilesFlow.first()
        assertEquals(1, profiles.size)
        val initial = profiles.first()
        assertEquals("Meu jogo de teste", initial.gameName)
        assertEquals(500, initial.score)

        val applyResult = editorRepository.applyChanges(
            profileId = initial.id,
            newValues = EditorValuesInput(score = 9999, coins = 450, lives = 7, energy = 100, xp = 500, level = 8),
            createAutoBackup = true
        )
        assertTrue(applyResult.isSuccess)
        assertEquals(9999, applyResult.getOrThrow().score)

        val logs = editorRepository.observeChangeLogs(initial.id).first()
        assertTrue(logs.any { it.fieldChanged == "Pontuação" && it.oldValue == "500" && it.newValue == "9999" })

        val backups = editorRepository.observeBackups(initial.id).first()
        assertTrue(backups.size >= 2)
        val preEditBackup = backups.first { it.score == 500 }

        val restored = editorRepository.restoreFromBackup(preEditBackup.id)
        assertTrue(restored.isSuccess)
        assertEquals(500, restored.getOrThrow().score)
    }

    @Test
    fun `editor rejects negative values and unauthorized third-party profiles`() = runTest {
        val validationError = editorRepository.validateInput(
            EditorValuesInput(score = -10, coins = 0, lives = 3, energy = 50, xp = 0, level = 1)
        )
        assertNotNull(validationError)

        val thirdPartyId = db.authorizedEditorDao().insertProfile(
            AuthorizedProfileEntity(
                gameName = "Jogo de Terceiro",
                packageName = "com.thirdparty.protected",
                isAuthorizedOwnGame = false,
                authorizationSource = "THIRD_PARTY",
                externalUri = null,
                score = 100,
                coins = 50,
                lives = 3,
                energy = 100,
                xp = 10,
                level = 1,
                updatedAt = System.currentTimeMillis()
            )
        )

        val blocked = editorRepository.applyChanges(
            profileId = thirdPartyId,
            newValues = EditorValuesInput(999, 999, 9, 100, 100, 10)
        )
        assertTrue(blocked.isFailure)
        assertTrue(blocked.exceptionOrNull() is SecurityException)
    }

    @Test
    fun `apk import via file uri persists in Room library and history saves full report`() = runTest {
        val apkFile = tempFolder.newFile("imported_test.apk")
        ZipOutputStream(FileOutputStream(apkFile)).use { zos ->
            zos.putNextEntry(ZipEntry("AndroidManifest.xml"))
            zos.write("manifest".toByteArray())
            zos.closeEntry()
            zos.putNextEntry(ZipEntry("classes.dex"))
            zos.write("playerScore playerCoins".toByteArray())
            zos.closeEntry()
        }

        val importResult = libraryRepository.importApkFromUri(
            uri = Uri.fromFile(apkFile),
            maxSizeMb = 50,
            maxEntries = 1000,
            deepDexScan = true
        )
        assertTrue(importResult.isSuccess)
        val (savedGame, _) = importResult.getOrThrow()

        val allGames = libraryRepository.gamesFlow.first()
        assertEquals(1, allGames.size)
        assertEquals(savedGame.sha256, allGames.first().sha256)

        val report = AnalysisReport(
            gameId = savedGame.id,
            gameName = savedGame.name,
            packageName = savedGame.packageName,
            analyzedAt = System.currentTimeMillis(),
            metadata = ApkTechnicalMetadata(
                appName = savedGame.name,
                packageName = savedGame.packageName,
                versionName = savedGame.versionName,
                versionCode = savedGame.versionCode,
                sizeBytes = savedGame.sizeBytes,
                sha256 = savedGame.sha256,
                minSdk = 24,
                targetSdk = 35,
                entryCount = 2,
                dexFiles = listOf("classes.dex"),
                nativeAbis = emptyList(),
                permissions = emptyList(),
                activitiesCount = 1,
                servicesCount = 0,
                receiversCount = 0,
                configFiles = emptyList(),
                isDebuggable = true,
                usesCleartextTraffic = false,
                hasOnlinePermissions = false
            ),
            variables = emptyList(),
            onlineLimitations = emptyList(),
            aiInterpretation = AiInterpretationResult(
                engineMode = "LOCAL_TECHNICAL_FALLBACK",
                isCloudAiActive = false,
                noticeBanner = "Aviso local",
                summary = "Resumo",
                architectureAssessment = "Arch",
                onlineRestrictionsSummary = "Offline",
                recommendations = listOf("Ok")
            ),
            errorsFound = emptyList(),
            fullTechnicalReportText = "RELATORIO COMPLETO"
        )
        val reportId = historyRepository.saveReport(report)
        val loaded = historyRepository.getFullReport(reportId)
        assertNotNull(loaded)
        assertEquals("RELATORIO COMPLETO", loaded?.fullTechnicalReportText)
    }
}
