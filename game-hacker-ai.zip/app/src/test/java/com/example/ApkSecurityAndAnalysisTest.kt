package com.example

import com.example.ai.LocalTechnicalGameAiEngine
import com.example.analysis.DexAndResourceScanner
import com.example.analysis.OnlineLimitationAnalyzer
import com.example.analysis.VariableDetector
import com.example.domain.ApkTechnicalMetadata
import com.example.domain.DetectionStatus
import com.example.security.ApkSecurityValidator
import com.example.security.ApkValidationResult
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ApkSecurityAndAnalysisTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    private val validator = ApkSecurityValidator()
    private val scanner = DexAndResourceScanner()
    private val detector = VariableDetector()
    private val onlineAnalyzer = OnlineLimitationAnalyzer()

    @Test
    fun `validator rejects non-zip invalid file`() {
        val fakeApk = tempFolder.newFile("corrupt.apk")
        fakeApk.writeText("NOT_A_VALID_APK_BINARY_CONTENT")

        val result = validator.validateApkFile(fakeApk)
        assertTrue(result is ApkValidationResult.Invalid)
    }

    @Test
    fun `validator rejects zip without AndroidManifest`() {
        val zipWithoutManifest = tempFolder.newFile("nomani.apk")
        ZipOutputStream(FileOutputStream(zipWithoutManifest)).use { zos ->
            zos.putNextEntry(ZipEntry("assets/config.json"))
            zos.write("""{"score": 100}""".toByteArray())
            zos.closeEntry()
        }

        val result = validator.validateApkFile(zipWithoutManifest)
        assertTrue(result is ApkValidationResult.Invalid)
    }

    @Test
    fun `validator rejects zip slip path traversal entry`() {
        val zipSlipFile = tempFolder.newFile("zipslip.apk")
        ZipOutputStream(FileOutputStream(zipSlipFile)).use { zos ->
            zos.putNextEntry(ZipEntry("../../evil.sh"))
            zos.write("echo bad".toByteArray())
            zos.closeEntry()
        }

        val result = validator.validateApkFile(zipSlipFile)
        assertTrue(result is ApkValidationResult.Invalid)
        val reason = (result as ApkValidationResult.Invalid).reason
        assertTrue(reason.contains("ZipSlip"))
    }

    @Test
    fun `validator accepts valid apk structure and scanner detects variables with proper epistemic status`() {
        val sampleApk = createSyntheticApkFile(
            name = "valid_game.apk",
            jsonConfig = """{"playerCoins": 250, "maxLives": 5, "level": 3}""",
            dexContent = "Lcom/demo/GameState; playerScore getCoins mEnergy okhttp3/OkHttpClient android.permission.INTERNET",
            resContent = "score_label txt_health"
        )

        val validation = validator.validateApkFile(sampleApk)
        assertTrue(validation is ApkValidationResult.Valid)
        val valid = validation as ApkValidationResult.Valid
        assertEquals(64, valid.sha256.length)
        assertEquals(1, valid.dexCount)

        val scan = scanner.scanApk(sampleApk, deepDexScan = true)
        assertTrue(scan.dexFiles.contains("classes.dex"))
        assertTrue(scan.configFiles.contains("assets/game_config.json"))

        val variables = detector.detectFromTokens(scan.tokens)
        assertTrue(variables.any { it.name == "Coins" && it.status == DetectionStatus.CONFIRMADO })
        assertTrue(variables.any { it.name == "Score" && it.status == DetectionStatus.PROVAVEL })
        assertTrue(variables.any { it.name == "Health" && it.status == DetectionStatus.IDENTIFICADO })
    }

    @Test
    fun `online limitation analyzer and local AI engine report online constraints honestly`() = runTest {
        val metadata = ApkTechnicalMetadata(
            appName = "Cyber Arena",
            packageName = "com.test.cyberarena",
            versionName = "2.1.0",
            versionCode = 21,
            sizeBytes = 1024 * 500,
            sha256 = "abc123",
            minSdk = 24,
            targetSdk = 35,
            entryCount = 42,
            dexFiles = listOf("classes.dex"),
            nativeAbis = listOf("arm64-v8a"),
            permissions = listOf("android.permission.INTERNET"),
            activitiesCount = 2,
            servicesCount = 1,
            receiversCount = 0,
            configFiles = listOf("assets/game_config.json"),
            isDebuggable = false,
            usesCleartextTraffic = false,
            hasOnlinePermissions = true
        )

        val sampleApk = createSyntheticApkFile(
            name = "online.apk",
            jsonConfig = """{"coins": 10}""",
            dexContent = "retrofit2/Retrofit com.google.firebase.firestore playintegrity",
            resContent = "score"
        )
        val scan = scanner.scanApk(sampleApk)
        val vars = detector.detectFromTokens(scan.tokens)
        val limits = onlineAnalyzer.analyze(metadata, scan.tokens)

        assertTrue(limits.any { it.severity == "ALTA" })
        assertTrue(limits.any { it.category == "ANTI_TAMPER" })

        val aiEngine = LocalTechnicalGameAiEngine()
        val aiResult = aiEngine.interpretTechnicalData(metadata, vars, limits)
        assertFalse(aiResult.isCloudAiActive)
        assertTrue(aiResult.noticeBanner.contains("Firebase AI Logic"))
        assertTrue(aiResult.summary.contains("Cyber Arena"))
    }

    private fun createSyntheticApkFile(
        name: String,
        jsonConfig: String,
        dexContent: String,
        resContent: String
    ): File {
        val file = tempFolder.newFile(name)
        ZipOutputStream(FileOutputStream(file)).use { zos ->
            zos.putNextEntry(ZipEntry("AndroidManifest.xml"))
            zos.write("android.permission.INTERNET com.demo.game".toByteArray())
            zos.closeEntry()

            zos.putNextEntry(ZipEntry("classes.dex"))
            zos.write(dexContent.toByteArray())
            zos.closeEntry()

            zos.putNextEntry(ZipEntry("resources.arsc"))
            zos.write(resContent.toByteArray())
            zos.closeEntry()

            zos.putNextEntry(ZipEntry("assets/game_config.json"))
            zos.write(jsonConfig.toByteArray())
            zos.closeEntry()
        }
        return file
    }
}
