package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasScrollAction
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun `read app name string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Game Hacker AI", appName)
    }

    @Test
    fun `home screen displays main branding and all 6 action panels`() {
        composeRule.waitForIdle()
        composeRule.onNodeWithText("GAME HACKER AI MASTER").assertIsDisplayed()

        val tags = listOf(
            "btn_add_apk",
            "btn_installed_games",
            "btn_analyze_ai",
            "btn_value_editor",
            "btn_history",
            "btn_settings"
        )
        tags.forEach { tag ->
            composeRule.onNode(hasScrollAction()).performScrollToNode(hasTestTag(tag))
            composeRule.onNodeWithTag(tag).assertIsDisplayed()
        }
    }

    @Test
    fun `navigating to value editor displays authorized test game and confirmation dialog`() {
        composeRule.waitForIdle()
        composeRule.onNode(hasScrollAction()).performScrollToNode(hasTestTag("btn_value_editor"))
        composeRule.onNodeWithTag("btn_value_editor").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("EDITOR DE VALORES").assertIsDisplayed()

        composeRule.waitUntil(timeoutMillis = 5_000) {
            composeRule.onAllNodes(hasText("JOGO: Meu jogo de teste")).fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithText("JOGO: Meu jogo de teste").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("input_score").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("btn_apply_changes").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Confirmar alterações?").assertIsDisplayed()
    }
}
