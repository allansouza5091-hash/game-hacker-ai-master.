package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.core.AppContainer
import com.example.feature.analysis.AnalysisScreen
import com.example.feature.analysis.AnalysisViewModel
import com.example.feature.editor.ValueEditorScreen
import com.example.feature.editor.ValueEditorViewModel
import com.example.feature.history.HistoryScreen
import com.example.feature.history.HistoryViewModel
import com.example.feature.home.HomeScreen
import com.example.feature.home.HomeViewModel
import com.example.feature.installed.InstalledGamesScreen
import com.example.feature.installed.InstalledGamesViewModel
import com.example.feature.settings.SettingsScreen
import com.example.feature.settings.SettingsViewModel
import com.example.ui.theme.DeepBlack
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.GameHackerTheme
import com.example.ui.theme.MutedSilver
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.PureWhite

object AppRoutes {
    const val HOME = "home"
    const val INSTALLED = "installed"
    const val ANALYSIS = "analysis"
    const val EDITOR = "editor"
    const val HISTORY = "history"
    const val SETTINGS = "settings"
}

private data class NavDestination(
    val route: String,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GameHackerTheme {
                GameHackerMasterApp()
            }
        }
    }
}

@Composable
fun GameHackerMasterApp() {
    val context = LocalContext.current
    val container = remember(context) { AppContainer(context) }

    val homeViewModel: HomeViewModel = viewModel(factory = HomeViewModel.Factory(container))
    val installedViewModel: InstalledGamesViewModel = viewModel(factory = InstalledGamesViewModel.Factory(container))
    val analysisViewModel: AnalysisViewModel = viewModel(factory = AnalysisViewModel.Factory(container))
    val editorViewModel: ValueEditorViewModel = viewModel(factory = ValueEditorViewModel.Factory(container))
    val historyViewModel: HistoryViewModel = viewModel(factory = HistoryViewModel.Factory(container))
    val settingsViewModel: SettingsViewModel = viewModel(factory = SettingsViewModel.Factory(container))

    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: AppRoutes.HOME

    val destinations = listOf(
        NavDestination(AppRoutes.HOME, R.string.nav_home, Icons.Rounded.Home, Icons.Outlined.Home, "nav_home"),
        NavDestination(AppRoutes.INSTALLED, R.string.nav_installed, Icons.Rounded.Apps, Icons.Outlined.Apps, "nav_installed"),
        NavDestination(AppRoutes.ANALYSIS, R.string.nav_analysis, Icons.Rounded.AutoAwesome, Icons.Outlined.AutoAwesome, "nav_analysis"),
        NavDestination(AppRoutes.EDITOR, R.string.nav_editor, Icons.Rounded.Tune, Icons.Outlined.Tune, "nav_editor"),
        NavDestination(AppRoutes.HISTORY, R.string.nav_history, Icons.Rounded.History, Icons.Outlined.History, "nav_history"),
        NavDestination(AppRoutes.SETTINGS, R.string.nav_settings, Icons.Rounded.Settings, Icons.Outlined.Settings, "nav_settings")
    )

    fun navigateTo(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
    ) {
        val useNavigationRail = maxWidth >= 680.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = DeepBlack,
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                if (!useNavigationRail) {
                    NavigationBar(
                        containerColor = ObsidianSurface,
                        contentColor = PureWhite,
                        windowInsets = WindowInsets.navigationBars
                    ) {
                        destinations.forEach { dest ->
                            val selected = currentRoute == dest.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTo(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = stringResource(dest.labelRes)
                                    )
                                },
                                label = {
                                    Text(
                                        text = stringResource(dest.labelRes),
                                        style = MaterialTheme.typography.labelSmall,
                                        maxLines = 1
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = ElectricBlue,
                                    selectedTextColor = ElectricBlue,
                                    indicatorColor = NeonPurple.copy(alpha = 0.25f),
                                    unselectedIconColor = MutedSilver,
                                    unselectedTextColor = MutedSilver
                                ),
                                modifier = Modifier.testTag(dest.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavigationRail) {
                    NavigationRail(
                        containerColor = ObsidianSurface,
                        contentColor = PureWhite,
                        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
                    ) {
                        destinations.forEach { dest ->
                            val selected = currentRoute == dest.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTo(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = stringResource(dest.labelRes)
                                    )
                                },
                                label = { Text(stringResource(dest.labelRes)) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = ElectricBlue,
                                    selectedTextColor = ElectricBlue,
                                    indicatorColor = NeonPurple.copy(alpha = 0.25f),
                                    unselectedIconColor = MutedSilver,
                                    unselectedTextColor = MutedSilver
                                ),
                                modifier = Modifier.testTag(dest.testTag)
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f)) {
                    NavHost(
                        navController = navController,
                        startDestination = AppRoutes.HOME
                    ) {
                        composable(AppRoutes.HOME) {
                            HomeScreen(
                                viewModel = homeViewModel,
                                onOpenInstalled = { navigateTo(AppRoutes.INSTALLED) },
                                onOpenAnalysis = { navigateTo(AppRoutes.ANALYSIS) },
                                onOpenEditor = { navigateTo(AppRoutes.EDITOR) },
                                onOpenHistory = { navigateTo(AppRoutes.HISTORY) },
                                onOpenSettings = { navigateTo(AppRoutes.SETTINGS) },
                                onApkImportedGoToAnalysis = { navigateTo(AppRoutes.ANALYSIS) }
                            )
                        }
                        composable(AppRoutes.INSTALLED) {
                            InstalledGamesScreen(
                                viewModel = installedViewModel,
                                onInspectApp = { app ->
                                    analysisViewModel.analyzeInstalledApp(app)
                                    navigateTo(AppRoutes.ANALYSIS)
                                }
                            )
                        }
                        composable(AppRoutes.ANALYSIS) {
                            AnalysisScreen(viewModel = analysisViewModel)
                        }
                        composable(AppRoutes.EDITOR) {
                            ValueEditorScreen(viewModel = editorViewModel)
                        }
                        composable(AppRoutes.HISTORY) {
                            HistoryScreen(viewModel = historyViewModel)
                        }
                        composable(AppRoutes.SETTINGS) {
                            SettingsScreen(viewModel = settingsViewModel)
                        }
                    }
                }
            }
        }
    }
}
