package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DeepBlack = Color(0xFF06070B)
val ObsidianSurface = Color(0xFF0D101B)
val CyberCard = Color(0xFF141829)
val CyberCardElevated = Color(0xFF1B2138)
val CyberOutline = Color(0xFF2B3354)

val NeonPurple = Color(0xFF9D4EDD)
val NeonPurpleBright = Color(0xFFC77DFF)
val NeonPurpleContainer = Color(0xFF2D1446)

val ElectricBlue = Color(0xFF00D4FF)
val ElectricBlueDeep = Color(0xFF2979FF)
val ElectricBlueContainer = Color(0xFF0C2A44)

val PureWhite = Color(0xFFF4F7FB)
val MutedSilver = Color(0xFFA0ACC8)
val DimSlate = Color(0xFF6C7896)

val CyberGreen = Color(0xFF10E8A5)
val CyberAmber = Color(0xFFFFB703)
val CyberRed = Color(0xFFFF4D6D)
