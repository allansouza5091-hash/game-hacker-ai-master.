package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val GameHackerColorScheme = darkColorScheme(
    primary = NeonPurpleBright,
    onPrimary = DeepBlack,
    primaryContainer = NeonPurpleContainer,
    onPrimaryContainer = PureWhite,
    secondary = ElectricBlue,
    onSecondary = DeepBlack,
    secondaryContainer = ElectricBlueContainer,
    onSecondaryContainer = PureWhite,
    tertiary = CyberGreen,
    onTertiary = DeepBlack,
    background = DeepBlack,
    onBackground = PureWhite,
    surface = ObsidianSurface,
    onSurface = PureWhite,
    surfaceVariant = CyberCard,
    onSurfaceVariant = MutedSilver,
    surfaceContainerLow = ObsidianSurface,
    surfaceContainer = CyberCard,
    surfaceContainerHigh = CyberCardElevated,
    outline = CyberOutline,
    outlineVariant = CyberOutline,
    error = CyberRed,
    onError = DeepBlack
)

val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun GameHackerTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = GameHackerColorScheme,
        typography = AppTypography,
        shapes = AppShapes,
        content = content
    )
}
