package com.example.domain

import android.graphics.Bitmap

sealed interface UiState<out T> {
    data object Idle : UiState<Nothing>
    data class Loading(val message: String = "") : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String, val detail: String? = null) : UiState<Nothing>
}

enum class AnalysisStatus(val label: String) {
    NOT_ANALYZED("Não analisado"),
    ANALYZING("Analisando"),
    COMPLETED("Concluída"),
    FAILED("Erro na análise")
}

enum class DetectionStatus(val label: String) {
    IDENTIFICADO("Identificado"),
    PROVAVEL("Provável"),
    CONFIRMADO("Confirmado")
}

enum class TechnicalOrigin(val label: String) {
    DEX_CODE("Código DEX / Símbolos"),
    RESOURCE_UI("Recursos / UI"),
    CONFIG_ASSET("Arquivo de Configuração / Asset"),
    MANIFEST("AndroidManifest.xml"),
    INSTALLED_METADATA("Metadados do Sistema")
}

data class GameRecord(
    val id: Long = 0,
    val name: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val sizeBytes: Long,
    val sourceUri: String?,
    val cachedApkPath: String?,
    val iconPath: String?,
    val sha256: String,
    val importedAt: Long,
    val analysisStatus: AnalysisStatus = AnalysisStatus.NOT_ANALYZED,
    val lastReportSummary: String? = null,
    val lastAnalysisId: Long? = null
)

data class InstalledAppInfo(
    val name: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val installedAt: Long?,
    val updatedAt: Long?,
    val isGame: Boolean,
    val isSystemApp: Boolean,
    val appTypeLabel: String,
    val sourceDir: String?,
    val iconBitmap: Bitmap? = null
)

data class DetectedVariable(
    val name: String,
    val category: String,
    val technicalLocation: String,
    val dataType: String,
    val evidence: String,
    val confidencePercent: Int,
    val origin: TechnicalOrigin,
    val status: DetectionStatus,
    val epistemicNote: String
)

data class OnlineLimitation(
    val title: String,
    val category: String,
    val severity: String,
    val evidence: String,
    val explanation: String,
    val officialApiNote: String
)

data class ApkTechnicalMetadata(
    val appName: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val sizeBytes: Long,
    val sha256: String,
    val minSdk: Int?,
    val targetSdk: Int?,
    val entryCount: Int,
    val dexFiles: List<String>,
    val nativeAbis: List<String>,
    val permissions: List<String>,
    val activitiesCount: Int,
    val servicesCount: Int,
    val receiversCount: Int,
    val configFiles: List<String>,
    val isDebuggable: Boolean,
    val usesCleartextTraffic: Boolean,
    val hasOnlinePermissions: Boolean
)

data class AiInterpretationResult(
    val engineMode: String,
    val isCloudAiActive: Boolean,
    val noticeBanner: String,
    val summary: String,
    val architectureAssessment: String,
    val onlineRestrictionsSummary: String,
    val recommendations: List<String>
)

data class AnalysisStep(
    val index: Int,
    val title: String,
    val completed: Boolean = false,
    val active: Boolean = false,
    val detail: String = ""
)

data class AnalysisReport(
    val id: Long = 0,
    val gameId: Long?,
    val gameName: String,
    val packageName: String,
    val analyzedAt: Long,
    val metadata: ApkTechnicalMetadata,
    val variables: List<DetectedVariable>,
    val onlineLimitations: List<OnlineLimitation>,
    val aiInterpretation: AiInterpretationResult,
    val errorsFound: List<String>,
    val fullTechnicalReportText: String
)

data class AuthorizedGameProfile(
    val id: Long = 0,
    val gameName: String,
    val packageName: String,
    val isAuthorizedOwnGame: Boolean,
    val authorizationSource: String,
    val externalUri: String? = null,
    val score: Int,
    val coins: Int,
    val lives: Int,
    val energy: Int,
    val xp: Int,
    val level: Int,
    val updatedAt: Long
)

data class ValueBackupSnapshot(
    val id: Long = 0,
    val profileId: Long,
    val gameName: String,
    val score: Int,
    val coins: Int,
    val lives: Int,
    val energy: Int,
    val xp: Int,
    val level: Int,
    val reason: String,
    val createdAt: Long
)

data class ValueChangeLog(
    val id: Long = 0,
    val profileId: Long,
    val fieldChanged: String,
    val oldValue: String,
    val newValue: String,
    val status: String,
    val timestamp: Long
)

data class AuditLogEntry(
    val id: Long = 0,
    val category: String,
    val message: String,
    val timestamp: Long
)

data class AppSettings(
    val maxApkSizeMb: Int = 250,
    val maxZipEntries: Int = 10000,
    val deepDexScanEnabled: Boolean = true,
    val autoBackupBeforeEdit: Boolean = true,
    val requireConfirmationBeforeEdit: Boolean = true
)
