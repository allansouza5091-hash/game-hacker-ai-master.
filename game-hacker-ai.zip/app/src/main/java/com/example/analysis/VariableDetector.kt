package com.example.analysis

import com.example.domain.DetectedVariable
import com.example.domain.DetectionStatus
import com.example.domain.TechnicalOrigin

class VariableDetector {

    private data class KeywordTarget(
        val canonicalName: String,
        val category: String,
        val aliases: List<String>
    )

    private val targets = listOf(
        KeywordTarget("Score", "Pontuação", listOf("score", "highscore", "pontuacao", "ponto")),
        KeywordTarget("Points", "Pontuação", listOf("points", "pontos", "pts")),
        KeywordTarget("Coins", "Economia", listOf("coins", "coin", "moedas", "moeda")),
        KeywordTarget("Gold", "Economia", listOf("gold", "ouro")),
        KeywordTarget("Gems", "Economia", listOf("gems", "gem", "gemas", "diamonds", "diamantes")),
        KeywordTarget("XP", "Progressão", listOf("xp", "exp", "experiencepoints")),
        KeywordTarget("Level", "Progressão", listOf("level", "lvl", "nivel", "stage")),
        KeywordTarget("Lives", "Sobrevivência", listOf("lives", "life", "vidas", "vida")),
        KeywordTarget("Energy", "Energia", listOf("energy", "stamina", "energia")),
        KeywordTarget("Health", "Sobrevivência", listOf("health", "hp", "hitpoints", "saude")),
        KeywordTarget("Experience", "Progressão", listOf("experience", "experiencia")),
        KeywordTarget("Currency", "Economia", listOf("currency", "wallet", "balance", "saldo"))
    )

    fun detectFromTokens(tokens: List<ExtractedToken>): List<DetectedVariable> {
        val detected = mutableListOf<DetectedVariable>()
        val seenKeys = mutableSetOf<String>()

        for (target in targets) {
            val matches = tokens.filter { tok ->
                val lower = tok.token.lowercase()
                target.aliases.any { alias ->
                    lower == alias ||
                        lower.contains("_$alias") ||
                        lower.contains("${alias}_") ||
                        lower.contains(".$alias") ||
                        lower.contains("${alias}.") ||
                        containsCamelCaseToken(tok.token, alias)
                }
            }

            // Rank strongest evidence first: JSON numeric config -> DEX structured identifier -> Resource/UI
            val prioritized = matches.sortedWith(
                compareByDescending<ExtractedToken> { it.jsonNumericValue != null }
                    .thenByDescending { it.origin == TechnicalOrigin.CONFIG_ASSET }
                    .thenByDescending { it.origin == TechnicalOrigin.DEX_CODE }
                    .thenBy { it.token.length }
            ).take(2)

            for (match in prioritized) {
                val dedupeKey = "${target.canonicalName}:${match.sourceFile}:${match.token}"
                if (!seenKeys.add(dedupeKey)) continue

                val isNumericJson = match.jsonNumericValue != null
                val isStructuredCode = match.origin == TechnicalOrigin.DEX_CODE &&
                    isLikelyFieldOrMethodIdentifier(match.token)
                val isUiOrGeneric = !isNumericJson && !isStructuredCode

                val status = when {
                    isNumericJson -> DetectionStatus.CONFIRMADO
                    isStructuredCode -> DetectionStatus.PROVAVEL
                    else -> DetectionStatus.IDENTIFICADO
                }

                val confidence = when {
                    isNumericJson -> 92
                    isStructuredCode && match.token.contains("/") -> 64
                    isStructuredCode -> 74
                    match.origin == TechnicalOrigin.CONFIG_ASSET -> 55
                    else -> 34
                }

                val dataType = when {
                    isNumericJson -> "Numérico em JSON (valor estático=${match.jsonNumericValue})"
                    isStructuredCode -> "Referência simbólica em DEX (tipo primitivo inferido)"
                    match.origin == TechnicalOrigin.RESOURCE_UI -> "Rótulo/Recurso visual ou string"
                    else -> "Referência textual não tipada"
                }

                val evidence = if (isNumericJson) {
                    "Chave \"${match.token}\" = ${match.jsonNumericValue}"
                } else {
                    match.token
                }

                val epistemicNote = when (status) {
                    DetectionStatus.CONFIRMADO ->
                        "Valor numérico estático encontrado explicitamente em arquivo de configuração (${match.sourceFile}). Ainda pode ser sobrescrito por servidor ou estado salvo."
                    DetectionStatus.PROVAVEL ->
                        "Identificador estruturado encontrado no código compilado (${match.sourceFile}). Indica provável símbolo de lógica do jogo, mas não confirma valor ativo em memória."
                    DetectionStatus.IDENTIFICADO ->
                        "Apenas referência nominal em recurso/texto (${match.sourceFile}). Encontrar a palavra '${target.canonicalName}' não significa que a variável real ou seu valor foram localizados."
                }

                detected.add(
                    DetectedVariable(
                        name = target.canonicalName,
                        category = target.category,
                        technicalLocation = "${match.sourceFile} • ${match.origin.label}",
                        dataType = dataType,
                        evidence = evidence,
                        confidencePercent = confidence,
                        origin = match.origin,
                        status = status,
                        epistemicNote = epistemicNote
                    )
                )
            }
        }

        return detected.sortedByDescending { it.confidencePercent }
    }

    private fun containsCamelCaseToken(raw: String, alias: String): Boolean {
        val normalized = raw.replace(Regex("([a-z])([A-Z])"), "$1_$2").lowercase()
        val parts = normalized.split('_', '.', '/', '$', '-')
        return parts.any { it == alias || (alias.length >= 4 && it.startsWith(alias)) }
    }

    private fun isLikelyFieldOrMethodIdentifier(token: String): Boolean {
        val lower = token.lowercase()
        if (lower.startsWith("ic_") || lower.startsWith("bg_") || lower.startsWith("lbl_") ||
            lower.startsWith("btn_") || lower.startsWith("tv_") || lower.startsWith("img_")
        ) {
            return false
        }
        return token.contains("_") ||
            token.any { it.isUpperCase() } ||
            token.startsWith("get") ||
            token.startsWith("set") ||
            token.startsWith("add") ||
            token.startsWith("m")
    }
}
