package com.example.analysis

import com.example.domain.TechnicalOrigin
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.util.zip.ZipFile

data class ExtractedToken(
    val token: String,
    val sourceFile: String,
    val origin: TechnicalOrigin,
    val jsonNumericValue: String? = null
)

data class ApkScanFindings(
    val entryCount: Int,
    val dexFiles: List<String>,
    val nativeAbis: List<String>,
    val configFiles: List<String>,
    val tokens: List<ExtractedToken>,
    val scanWarnings: List<String>
)

class DexAndResourceScanner {

    fun scanApk(
        apkFile: File,
        deepDexScan: Boolean = true,
        maxEntries: Int = 10_000
    ): ApkScanFindings {
        val dexFiles = mutableListOf<String>()
        val nativeAbis = linkedSetOf<String>()
        val configFiles = mutableListOf<String>()
        val tokens = mutableListOf<ExtractedToken>()
        val warnings = mutableListOf<String>()
        var entryCount = 0

        ZipFile(apkFile).use { zip ->
            val entries = zip.entries()
            while (entries.hasMoreElements() && entryCount < maxEntries) {
                val entry = entries.nextElement()
                entryCount++
                val name = entry.name
                if (name.contains("..") || name.startsWith("/")) continue

                when {
                    name.startsWith("classes") && name.endsWith(".dex") -> {
                        dexFiles.add(name)
                        if (deepDexScan && tokens.size < MAX_TOTAL_TOKENS) {
                            zip.getInputStream(entry).use { stream ->
                                val dexBytes = readBoundedBytes(stream, MAX_DEX_READ_BYTES)
                                if (entry.size > MAX_DEX_READ_BYTES) {
                                    warnings.add("$name truncado a ${MAX_DEX_READ_BYTES / 1024} KB para proteção de memória.")
                                }
                                extractAsciiIdentifiers(dexBytes, MAX_TOKENS_PER_DEX).forEach { tok ->
                                    if (tokens.size < MAX_TOTAL_TOKENS) {
                                        tokens.add(ExtractedToken(tok, name, TechnicalOrigin.DEX_CODE))
                                    }
                                }
                            }
                        }
                    }

                    name.startsWith("lib/") && name.endsWith(".so") -> {
                        val parts = name.split("/")
                        if (parts.size >= 3) {
                            nativeAbis.add(parts[1])
                        }
                    }

                    name == "resources.arsc" -> {
                        if (tokens.size < MAX_TOTAL_TOKENS) {
                            zip.getInputStream(entry).use { stream ->
                                val resBytes = readBoundedBytes(stream, MAX_ARSC_READ_BYTES)
                                extractAsciiIdentifiers(resBytes, MAX_TOKENS_PER_RES).forEach { tok ->
                                    if (tokens.size < MAX_TOTAL_TOKENS) {
                                        tokens.add(ExtractedToken(tok, name, TechnicalOrigin.RESOURCE_UI))
                                    }
                                }
                            }
                        }
                    }

                    name == "AndroidManifest.xml" -> {
                        zip.getInputStream(entry).use { stream ->
                            val manifestBytes = readBoundedBytes(stream, MAX_CONFIG_READ_BYTES)
                            extractUtf16AndAsciiStrings(manifestBytes, 400).forEach { tok ->
                                if (tokens.size < MAX_TOTAL_TOKENS) {
                                    tokens.add(ExtractedToken(tok, name, TechnicalOrigin.MANIFEST))
                                }
                            }
                        }
                    }

                    isConfigOrAssetTextFile(name) -> {
                        configFiles.add(name)
                        if (tokens.size < MAX_TOTAL_TOKENS) {
                            zip.getInputStream(entry).use { stream ->
                                val cfgBytes = readBoundedBytes(stream, MAX_CONFIG_READ_BYTES)
                                val text = cfgBytes.toString(Charsets.UTF_8)
                                if (name.endsWith(".json", ignoreCase = true)) {
                                    extractJsonTokens(text, name, tokens)
                                } else {
                                    extractAsciiIdentifiers(cfgBytes, 300).forEach { tok ->
                                        if (tokens.size < MAX_TOTAL_TOKENS) {
                                            tokens.add(ExtractedToken(tok, name, TechnicalOrigin.CONFIG_ASSET))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        return ApkScanFindings(
            entryCount = entryCount,
            dexFiles = dexFiles.sorted(),
            nativeAbis = nativeAbis.sorted(),
            configFiles = configFiles.sorted(),
            tokens = tokens,
            scanWarnings = warnings
        )
    }

    private fun isConfigOrAssetTextFile(name: String): Boolean {
        if (!name.startsWith("assets/") && !name.startsWith("res/raw/") && !name.startsWith("res/xml/")) {
            return false
        }
        val lower = name.lowercase()
        return lower.endsWith(".json") ||
            lower.endsWith(".xml") ||
            lower.endsWith(".cfg") ||
            lower.endsWith(".ini") ||
            lower.endsWith(".properties") ||
            lower.endsWith(".txt")
    }

    private fun extractJsonTokens(text: String, sourceFile: String, out: MutableList<ExtractedToken>) {
        val trimmed = text.trim()
        try {
            when {
                trimmed.startsWith("{") -> walkJsonObject(JSONObject(trimmed), "", sourceFile, out)
                trimmed.startsWith("[") -> walkJsonArray(JSONArray(trimmed), "", sourceFile, out)
            }
        } catch (_: Throwable) {
            val kvRegex = Regex("\"([A-Za-z0-9_.-]{2,64})\"\\s*:\\s*(-?\\d+(?:\\.\\d+)?)")
            kvRegex.findAll(trimmed).forEach { match ->
                if (out.size < MAX_TOTAL_TOKENS) {
                    out.add(
                        ExtractedToken(
                            token = match.groupValues[1],
                            sourceFile = sourceFile,
                            origin = TechnicalOrigin.CONFIG_ASSET,
                            jsonNumericValue = match.groupValues[2]
                        )
                    )
                }
            }
            extractAsciiIdentifiers(text.toByteArray(Charsets.UTF_8), 200).forEach { tok ->
                if (out.size < MAX_TOTAL_TOKENS) {
                    out.add(ExtractedToken(tok, sourceFile, TechnicalOrigin.CONFIG_ASSET))
                }
            }
        }
    }

    private fun walkJsonObject(
        obj: JSONObject,
        prefix: String,
        sourceFile: String,
        out: MutableList<ExtractedToken>
    ) {
        val keys = obj.keys()
        while (keys.hasNext() && out.size < MAX_TOTAL_TOKENS) {
            val key = keys.next()
            val fullKey = if (prefix.isEmpty()) key else "$prefix.$key"
            val value = obj.opt(key)
            when (value) {
                is Number -> {
                    out.add(
                        ExtractedToken(
                            token = fullKey,
                            sourceFile = sourceFile,
                            origin = TechnicalOrigin.CONFIG_ASSET,
                            jsonNumericValue = value.toString()
                        )
                    )
                }
                is JSONObject -> walkJsonObject(value, fullKey, sourceFile, out)
                is JSONArray -> walkJsonArray(value, fullKey, sourceFile, out)
                else -> {
                    out.add(ExtractedToken(fullKey, sourceFile, TechnicalOrigin.CONFIG_ASSET))
                }
            }
        }
    }

    private fun walkJsonArray(
        arr: JSONArray,
        prefix: String,
        sourceFile: String,
        out: MutableList<ExtractedToken>
    ) {
        val limit = minOf(arr.length(), 40)
        for (i in 0 until limit) {
            if (out.size >= MAX_TOTAL_TOKENS) break
            val value = arr.opt(i)
            when (value) {
                is JSONObject -> walkJsonObject(value, "$prefix[$i]", sourceFile, out)
                is JSONArray -> walkJsonArray(value, "$prefix[$i]", sourceFile, out)
            }
        }
    }

    internal fun readBoundedBytes(stream: InputStream, maxBytes: Int): ByteArray {
        val buffer = ByteArray(8192)
        val output = java.io.ByteArrayOutputStream()
        var total = 0
        while (total < maxBytes) {
            val toRead = minOf(buffer.size, maxBytes - total)
            val read = stream.read(buffer, 0, toRead)
            if (read == -1) break
            output.write(buffer, 0, read)
            total += read
        }
        return output.toByteArray()
    }

    internal fun extractAsciiIdentifiers(bytes: ByteArray, limit: Int): List<String> {
        val result = linkedSetOf<String>()
        val sb = StringBuilder()
        for (b in bytes) {
            val ch = (b.toInt() and 0xFF)
            val isIdentChar = (ch in 'a'.code..'z'.code) ||
                (ch in 'A'.code..'Z'.code) ||
                (ch in '0'.code..'9'.code) ||
                ch == '_'.code ||
                ch == '.'.code ||
                ch == '/'.code
            if (isIdentChar) {
                if (sb.length < 72) sb.append(ch.toChar())
            } else {
                if (sb.length in 3..72) {
                    result.add(sb.toString())
                    if (result.size >= limit) break
                }
                sb.setLength(0)
            }
        }
        if (sb.length in 3..72 && result.size < limit) {
            result.add(sb.toString())
        }
        return result.toList()
    }

    private fun extractUtf16AndAsciiStrings(bytes: ByteArray, limit: Int): List<String> {
        val combined = linkedSetOf<String>()
        combined.addAll(extractAsciiIdentifiers(bytes, limit / 2))
        // Also scan simple UTF-16LE ASCII characters commonly stored in binary AndroidManifest.xml
        val sb = StringBuilder()
        var i = 0
        while (i + 1 < bytes.size && combined.size < limit) {
            val lo = bytes[i].toInt() and 0xFF
            val hi = bytes[i + 1].toInt() and 0xFF
            if (hi == 0 && ((lo in 'a'.code..'z'.code) || (lo in 'A'.code..'Z'.code) ||
                    (lo in '0'.code..'9'.code) || lo == '_'.code || lo == '.'.code)
            ) {
                if (sb.length < 72) sb.append(lo.toChar())
            } else {
                if (sb.length in 4..72) {
                    combined.add(sb.toString())
                }
                sb.setLength(0)
            }
            i += 2
        }
        return combined.toList()
    }

    companion object {
        private const val MAX_DEX_READ_BYTES = 4 * 1024 * 1024
        private const val MAX_ARSC_READ_BYTES = 2 * 1024 * 1024
        private const val MAX_CONFIG_READ_BYTES = 256 * 1024
        private const val MAX_TOKENS_PER_DEX = 2500
        private const val MAX_TOKENS_PER_RES = 1200
        private const val MAX_TOTAL_TOKENS = 8000
    }
}
