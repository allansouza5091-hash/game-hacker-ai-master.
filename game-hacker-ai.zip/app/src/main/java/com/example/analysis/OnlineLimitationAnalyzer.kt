package com.example.analysis

import com.example.domain.ApkTechnicalMetadata
import com.example.domain.OnlineLimitation

class OnlineLimitationAnalyzer {

    fun analyze(
        metadata: ApkTechnicalMetadata,
        tokens: List<ExtractedToken>
    ): List<OnlineLimitation> {
        val limitations = mutableListOf<OnlineLimitation>()
        val lowerTokens = tokens.map { it.token.lowercase() }

        val hasInternet = metadata.permissions.any { it == "android.permission.INTERNET" } ||
            lowerTokens.any { it.contains("android.permission.internet") }

        val hasBilling = metadata.permissions.any { it.contains("BILLING") } ||
            lowerTokens.any { it.contains("com.android.vending.billing") || it.contains("billingclient") }

        val hasPlayGames = lowerTokens.any {
            it.contains("gms.games") || it.contains("playgames") || it.contains("snapshotsclient") || it.contains("leaderboards")
        }

        val hasNetworkingLibs = lowerTokens.filter {
            it.contains("okhttp") || it.contains("retrofit") || it.contains("grpc") ||
                it.contains("websocket") || it.contains("ktor") || it.contains("volley")
        }.distinct().take(3)

        val hasCloudBackend = lowerTokens.filter {
            it.contains("firebase") || it.contains("firestore") || it.contains("amazonaws") ||
                it.contains("playfab") || it.contains("photon") || it.contains("supabase")
        }.distinct().take(3)

        val hasIntegrityOrAntiTamper = lowerTokens.filter {
            it.contains("playintegrity") || it.contains("safetynet") || it.contains("frida") ||
                it.contains("rootbeer") || it.contains("xposed") || it.contains("antitamper") ||
                it.contains("integritymanager")
        }.distinct().take(3)

        if (hasInternet) {
            limitations.add(
                OnlineLimitation(
                    title = "Conectividade de Rede e Sincronização Remota",
                    category = "SERVER_AUTHORITATIVE",
                    severity = "ALTA",
                    evidence = "Permissão android.permission.INTERNET detectada",
                    explanation = "Aplicativos conectados à internet frequentemente validam pontuação, inventário e progresso no servidor remoto. Alterações locais isoladas são descartadas ou rejeitadas na sincronização.",
                    officialApiNote = "Integrações permitidas exigem endpoints oficiais e autenticação autorizada do desenvolvedor."
                )
            )
        }

        if (hasCloudBackend.isNotEmpty() || hasNetworkingLibs.isNotEmpty()) {
            val evidenceList = (hasCloudBackend + hasNetworkingLibs).joinToString(", ")
            limitations.add(
                OnlineLimitation(
                    title = "Dependência de APIs Externas e Estado em Nuvem",
                    category = "EXTERNAL_API",
                    severity = "ALTA",
                    evidence = "Referências encontradas: $evidenceList",
                    explanation = "Foram detectados indícios de SDKs de rede ou nuvem. Moedas, ranking e dados da conta podem residir em banco de dados remoto sob controle exclusivo do servidor.",
                    officialApiNote = "Não é permitido alterar servidores de terceiros, contas de usuários ou resultados competitivos."
                )
            )
        }

        if (hasBilling) {
            limitations.add(
                OnlineLimitation(
                    title = "Economia Protegida por Compras e Recibos",
                    category = "STORE_BILLING",
                    severity = "ALTA",
                    evidence = "Referência ao Google Play Billing / BILLING permission",
                    explanation = "Moedas premium e gemas vinculadas a compras no app passam por verificação de assinatura/recibo entre a loja e o servidor do jogo.",
                    officialApiNote = "Somente a API oficial de faturamento do próprio aplicativo pode conceder itens comprados."
                )
            )
        }

        if (hasIntegrityOrAntiTamper.isNotEmpty()) {
            limitations.add(
                OnlineLimitation(
                    title = "Proteção Contra Adulteração e Integridade",
                    category = "ANTI_TAMPER",
                    severity = "ALTA",
                    evidence = "Indicadores: ${hasIntegrityOrAntiTamper.joinToString(", ")}",
                    explanation = "O pacote contém referências a verificação de integridade ou detecção de ambiente modificado. O app não tenta contornar mecanismos antitrapaça.",
                    officialApiNote = "Modificações devem ocorrer apenas em builds próprios/autorizados pelo titular."
                )
            )
        }

        if (hasPlayGames) {
            limitations.add(
                OnlineLimitation(
                    title = "Integração Oficial Google Play Games Services",
                    category = "ACCOUNT_SYNC",
                    severity = "MEDIA",
                    evidence = "Referências a Play Games / Leaderboards / Snapshots",
                    explanation = "Placares e conquistas oficiais sincronizados com a conta do jogador são protegidos por políticas da plataforma e validação remota.",
                    officialApiNote = "Utilize apenas SDKs e APIs oficiais em jogos desenvolvidos por você."
                )
            )
        }

        if (limitations.isEmpty()) {
            limitations.add(
                OnlineLimitation(
                    title = "Perfil Offline / Sem Indicadores Online Fortes",
                    category = "SERVER_AUTHORITATIVE",
                    severity = "INFORMATIVA",
                    evidence = "Nenhuma permissão INTERNET ou SDK cloud explícito detectado na varredura inicial",
                    explanation = "Embora não tenham sido encontrados indicadores óbvios de rede nos metadados escaneados, bibliotecas nativas (.so) ou strings ofuscadas ainda podem realizar conexões.",
                    officialApiNote = "Edições devem continuar restritas a projetos próprios ou expressamente autorizados."
                )
            )
        }

        return limitations
    }
}
