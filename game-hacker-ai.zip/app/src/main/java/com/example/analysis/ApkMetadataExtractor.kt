package com.example.analysis

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import com.example.domain.ApkTechnicalMetadata
import com.example.security.ApkSecurityValidator
import com.example.security.ApkValidationResult
import java.io.File
import java.io.FileOutputStream

data class ApkImportOutcome(
    val metadata: ApkTechnicalMetadata,
    val cachedApkPath: String,
    val iconPath: String?,
    val sourceUri: String,
    val scanFindings: ApkScanFindings,
    val warnings: List<String>
)

class ApkMetadataExtractor(
    private val context: Context,
    private val validator: ApkSecurityValidator = ApkSecurityValidator(),
    private val scanner: DexAndResourceScanner = DexAndResourceScanner()
) {

    fun importAndExtractFromUri(
        uri: Uri,
        maxSizeMb: Int = 250,
        maxEntries: Int = 10_000,
        deepDexScan: Boolean = true
    ): Result<ApkImportOutcome> {
        return try {
            val importDir = File(context.filesDir, "imported_apks").apply { mkdirs() }
            val tempFile = File(importDir, "temp_import_${System.currentTimeMillis()}.apk")
            val maxBytes = maxSizeMb.toLong() * 1024L * 1024L

            val displayName = resolveDisplayName(uri) ?: "imported_game.apk"
            var copiedBytes = 0L

            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tempFile).use { output ->
                    val buffer = ByteArray(16 * 1024)
                    var read = input.read(buffer)
                    while (read != -1) {
                        copiedBytes += read
                        if (copiedBytes > maxBytes) {
                            tempFile.delete()
                            return Result.failure(
                                IllegalArgumentException("Arquivo excede o limite de segurança de $maxSizeMb MB.")
                            )
                        }
                        output.write(buffer, 0, read)
                        read = input.read(buffer)
                    }
                }
            } ?: run {
                tempFile.delete()
                return Result.failure(IllegalStateException("Não foi possível abrir o arquivo selecionado pelo Android SAF."))
            }

            val validation = validator.validateApkFile(tempFile, maxBytes, maxEntries)
            when (validation) {
                is ApkValidationResult.Invalid -> {
                    tempFile.delete()
                    Result.failure(IllegalArgumentException(validation.reason))
                }
                is ApkValidationResult.Valid -> {
                    val safeName = "apk_${validation.sha256.take(16)}.apk"
                    val finalFile = File(importDir, safeName)
                    if (finalFile.exists()) finalFile.delete()
                    if (!tempFile.renameTo(finalFile)) {
                        tempFile.copyTo(finalFile, overwrite = true)
                        tempFile.delete()
                    }
                    extractFromValidatedFile(
                        apkFile = finalFile,
                        validation = validation,
                        fallbackName = displayName.removeSuffix(".apk"),
                        sourceUri = uri.toString(),
                        maxEntries = maxEntries,
                        deepDexScan = deepDexScan
                    )
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun extractFromValidatedFile(
        apkFile: File,
        validation: ApkValidationResult.Valid? = null,
        fallbackName: String = apkFile.nameWithoutExtension,
        sourceUri: String = apkFile.absolutePath,
        maxEntries: Int = 10_000,
        deepDexScan: Boolean = true
    ): Result<ApkImportOutcome> {
        return try {
            val validResult = validation ?: when (val res = validator.validateApkFile(apkFile, maxEntries = maxEntries)) {
                is ApkValidationResult.Invalid -> return Result.failure(IllegalArgumentException(res.reason))
                is ApkValidationResult.Valid -> res
            }

            val pm = context.packageManager
            val flags = PackageManager.GET_PERMISSIONS or
                PackageManager.GET_ACTIVITIES or
                PackageManager.GET_SERVICES or
                PackageManager.GET_RECEIVERS

            val pkgInfo = getPackageArchiveInfoCompat(pm, apkFile.absolutePath, flags)
            val appInfo = pkgInfo?.applicationInfo?.apply {
                sourceDir = apkFile.absolutePath
                publicSourceDir = apkFile.absolutePath
            }

            val label = appInfo?.loadLabel(pm)?.toString()?.takeIf { it.isNotBlank() }
                ?: fallbackName.ifBlank { "APK Sem Nome" }
            val packageName = pkgInfo?.packageName ?: "desconhecido.${validResult.sha256.take(8)}"
            val versionName = pkgInfo?.versionName ?: "1.0"
            val versionCode = if (pkgInfo != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) pkgInfo.longVersionCode
                else @Suppress("DEPRECATION") pkgInfo.versionCode.toLong()
            } else 1L

            val iconPath = appInfo?.let { info ->
                runCatching {
                    val drawable = info.loadIcon(pm)
                    saveDrawableIcon(drawable, validResult.sha256.take(16))
                }.getOrNull()
            }

            val scanFindings = scanner.scanApk(apkFile, deepDexScan = deepDexScan, maxEntries = maxEntries)
            val permissions = pkgInfo?.requestedPermissions?.toList().orEmpty()
            val isDebuggable = appInfo != null && (appInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
            val minSdk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) appInfo?.minSdkVersion else null
            val targetSdk = appInfo?.targetSdkVersion

            val metadata = ApkTechnicalMetadata(
                appName = label,
                packageName = packageName,
                versionName = versionName,
                versionCode = versionCode,
                sizeBytes = validResult.sizeBytes,
                sha256 = validResult.sha256,
                minSdk = minSdk,
                targetSdk = targetSdk,
                entryCount = scanFindings.entryCount,
                dexFiles = scanFindings.dexFiles,
                nativeAbis = scanFindings.nativeAbis,
                permissions = permissions,
                activitiesCount = pkgInfo?.activities?.size ?: 0,
                servicesCount = pkgInfo?.services?.size ?: 0,
                receiversCount = pkgInfo?.receivers?.size ?: 0,
                configFiles = scanFindings.configFiles,
                isDebuggable = isDebuggable,
                usesCleartextTraffic = false,
                hasOnlinePermissions = permissions.any {
                    it == "android.permission.INTERNET" || it == "android.permission.ACCESS_NETWORK_STATE"
                }
            )

            Result.success(
                ApkImportOutcome(
                    metadata = metadata,
                    cachedApkPath = apkFile.absolutePath,
                    iconPath = iconPath,
                    sourceUri = sourceUri,
                    scanFindings = scanFindings,
                    warnings = validResult.warnings + scanFindings.scanWarnings
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun resolveDisplayName(uri: Uri): String? {
        return runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) cursor.getString(idx) else null
                } else null
            }
        }.getOrNull()
    }

    private fun getPackageArchiveInfoCompat(
        pm: PackageManager,
        archivePath: String,
        flags: Int
    ): PackageInfo? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getPackageArchiveInfo(archivePath, PackageManager.PackageInfoFlags.of(flags.toLong()))
        } else {
            @Suppress("DEPRECATION")
            pm.getPackageArchiveInfo(archivePath, flags)
        }
    }

    private fun saveDrawableIcon(drawable: Drawable, idKey: String): String? {
        val iconDir = File(context.filesDir, "game_icons").apply { mkdirs() }
        val iconFile = File(iconDir, "icon_$idKey.png")
        val bitmap = drawableToBitmap(drawable)
        FileOutputStream(iconFile).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 95, out)
        }
        return iconFile.absolutePath
    }

    companion object {
        fun drawableToBitmap(drawable: Drawable): Bitmap {
            if (drawable is BitmapDrawable && drawable.bitmap != null) {
                return drawable.bitmap
            }
            val width = drawable.intrinsicWidth.takeIf { it > 0 } ?: 96
            val height = drawable.intrinsicHeight.takeIf { it > 0 } ?: 96
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            drawable.setBounds(0, 0, canvas.width, canvas.height)
            drawable.draw(canvas)
            return bitmap
        }
    }
}
