package com.example.core

import android.content.Context
import com.example.ai.GameAiEngine
import com.example.ai.LocalTechnicalGameAiEngine
import com.example.analysis.ApkMetadataExtractor
import com.example.analysis.DexAndResourceScanner
import com.example.analysis.OnlineLimitationAnalyzer
import com.example.analysis.VariableDetector
import com.example.data.AnalysisHistoryRepository
import com.example.data.AuthorizedEditorRepository
import com.example.data.GameLibraryRepository
import com.example.data.InstalledGamesRepository
import com.example.data.SettingsRepository
import com.example.data.db.AuditLogEntity
import com.example.data.db.GameHackerDatabase
import com.example.domain.AuditLogEntry
import com.example.security.ApkSecurityValidator
import com.example.security.CryptoVaultManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AppContainer(context: Context) {
    private val appContext = context.applicationContext
    val database: GameHackerDatabase = GameHackerDatabase.getInstance(appContext)
    val cryptoVault = CryptoVaultManager()
    val apkValidator = ApkSecurityValidator()
    val dexScanner = DexAndResourceScanner()
    val metadataExtractor = ApkMetadataExtractor(appContext, apkValidator, dexScanner)
    val variableDetector = VariableDetector()
    val onlineLimitationAnalyzer = OnlineLimitationAnalyzer()
    val aiEngine: GameAiEngine = LocalTechnicalGameAiEngine()

    val settingsRepository = SettingsRepository(appContext, cryptoVault)
    val installedGamesRepository = InstalledGamesRepository(appContext)
    val gameLibraryRepository = GameLibraryRepository(
        gameDao = database.gameDao(),
        auditLogDao = database.auditLogDao(),
        metadataExtractor = metadataExtractor
    )
    val analysisHistoryRepository = AnalysisHistoryRepository(database.analysisHistoryDao())
    val authorizedEditorRepository = AuthorizedEditorRepository(
        context = appContext,
        editorDao = database.authorizedEditorDao(),
        auditLogDao = database.auditLogDao()
    )
    val analysisOrchestrator = GameAnalysisOrchestrator(
        metadataExtractor = metadataExtractor,
        variableDetector = variableDetector,
        onlineLimitationAnalyzer = onlineLimitationAnalyzer,
        aiEngine = aiEngine,
        gameLibraryRepository = gameLibraryRepository,
        historyRepository = analysisHistoryRepository,
        auditLogDao = database.auditLogDao()
    )

    val auditLogsFlow: Flow<List<AuditLogEntry>> = database.auditLogDao().observeRecent().map { list ->
        list.map { AuditLogEntry(it.id, it.category, it.message, it.timestamp) }
    }

    suspend fun clearAuditLogs() {
        database.auditLogDao().clearAll()
        database.auditLogDao().insert(
            AuditLogEntity(
                category = "SECURITY",
                message = "Registros técnicos limpos pelo usuário.",
                timestamp = System.currentTimeMillis()
            )
        )
    }
}

object Formatters {
    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0L) return "N/D"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        return when {
            mb >= 1.0 -> String.format(Locale.getDefault(), "%.2f MB", mb)
            kb >= 1.0 -> String.format(Locale.getDefault(), "%.1f KB", kb)
            else -> "$bytes B"
        }
    }

    fun formatDateTime(epochMillis: Long?): String {
        if (epochMillis == null || epochMillis <= 0L) return "N/D"
        val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        return fmt.format(Date(epochMillis))
    }
}
