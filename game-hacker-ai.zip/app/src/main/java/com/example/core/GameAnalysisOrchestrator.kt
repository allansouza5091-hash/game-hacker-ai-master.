package com.example.core

import com.example.ai.GameAiEngine
import com.example.analysis.ApkMetadataExtractor
import com.example.analysis.ApkScanFindings
import com.example.analysis.OnlineLimitationAnalyzer
import com.example.analysis.VariableDetector
import com.example.data.AnalysisHistoryRepository
import com.example.data.GameLibraryRepository
import com.example.data.db.AuditLogDao
import com.example.data.db.AuditLogEntity
import com.example.domain.AnalysisReport
import com.example.domain.AnalysisStatus
import com.example.domain.AnalysisStep
import com.example.domain.ApkTechnicalMetadata
import com.example.domain.AppSettings
import com.example.domain.DetectionStatus
import com.example.domain.GameRecord
import com.example.domain.InstalledAppInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import java.io.File

sealed interface AnalysisPipelineEvent {
    data class Progress(val steps: List<AnalysisStep>) : AnalysisPipelineEvent
    data class Finished(val report: AnalysisReport) : AnalysisPipelineEvent
    data class Failed(val message: String) : AnalysisPipelineEvent
}

class GameAnalysisOrchestrator(
    private val metadataExtractor: ApkMetadataExtractor,
    private val variableDetector: VariableDetector,
    private val onlineLimitationAnalyzer: OnlineLimitationAnalyzer,
    private val aiEngine: GameAiEngine,
    private val gameLibraryRepository: GameLibraryRepository,
    private val historyRepository: AnalysisHistoryRepository,
    private val auditLogDao: AuditLogDao
) {
    private val stepTitles = listOf(
        "Preparando análise",
        "Validando arquivo",
        "Extraindo metadados",
        "Examinando recursos",
        "Identificando estruturas",
        "Procurando referências a pontuação",
        "Procurando referências a moedas",
        "Procurando referências a vidas",
        "Gerando relatório"
    )

    fun analyzeGameRecord(
        game: GameRecord,
        settings: AppSettings
    ): Flow<AnalysisPipelineEvent> = flow {
        val steps = stepTitles.mapIndexed { idx, title ->
            AnalysisStep(index = idx, title = title, active = idx == 0)
        }.toMutableList()

        suspend fun emitStep(activeIndex: Int, detail: String = "") {
            for (i in steps.indices) {
                steps[i] = steps[i].copy(
                    completed = i < activeIndex,
                    active = i == activeIndex,
                    detail = if (i == activeIndex) detail else steps[i].detail
                )
            }
            emit(AnalysisPipelineEvent.Progress(steps.toList()))
        }

        try {
            gameLibraryRepository.updateAnalysisState(game.id, AnalysisStatus.ANALYZING)
            emitStep(0, "Inicializando ambiente seguro de análise estática...")

            val apkPath = game.cachedApkPath
                ?: throw IllegalStateException("Caminho do arquivo APK não disponível no cache interno.")
            val apkFile = File(apkPath)

            emitStep(1, "Verificando integridade ZIP, assinatura PK e limites de segurança...")
            val extractionResult = metadataExtractor.extractFromValidatedFile(
                apkFile = apkFile,
                fallbackName = game.name,
                sourceUri = game.sourceUri ?: apkPath,
                maxEntries = settings.maxZipEntries,
                deepDexScan = settings.deepDexScanEnabled
            )
            val outcome = extractionResult.getOrElse { throw it }

            emitStep(2, "Pacote ${outcome.metadata.packageName} v${outcome.metadata.versionName}")
            emitStep(3, "${outcome.scanFindings.entryCount} entradas e ${outcome.metadata.configFiles.size} arquivo(s) de configuração")
            emitStep(4, "${outcome.metadata.dexFiles.size} DEX • ABIs: ${outcome.metadata.nativeAbis.ifEmpty { listOf("Dalvik/ART") }.joinToString()}")

            val allVariables = variableDetector.detectFromTokens(outcome.scanFindings.tokens)

            emitStep(5, "${allVariables.count { it.category == "Pontuação" }} referência(s) de pontuação analisadas")
            emitStep(6, "${allVariables.count { it.category == "Economia" }} referência(s) de economia analisadas")
            emitStep(7, "${allVariables.count { it.category == "Sobrevivência" || it.category == "Energia" }} referência(s) de vidas/energia analisadas")

            emitStep(8, "Consolidando limitações online e relatório técnico...")
            val limitations = onlineLimitationAnalyzer.analyze(outcome.metadata, outcome.scanFindings.tokens)
            val aiResult = aiEngine.interpretTechnicalData(outcome.metadata, allVariables, limitations)

            val now = System.currentTimeMillis()
            val textReport = buildTechnicalReportText(
                metadata = outcome.metadata,
                variables = allVariables,
                limitations = limitations,
                warnings = outcome.warnings,
                aiSummary = aiResult.summary,
                aiNotice = aiResult.noticeBanner
            )

            val draftReport = AnalysisReport(
                gameId = game.id,
                gameName = outcome.metadata.appName,
                packageName = outcome.metadata.packageName,
                analyzedAt = now,
                metadata = outcome.metadata,
                variables = allVariables,
                onlineLimitations = limitations,
                aiInterpretation = aiResult,
                errorsFound = outcome.warnings,
                fullTechnicalReportText = textReport
            )

            val savedId = historyRepository.saveReport(draftReport)
            val finalReport = draftReport.copy(id = savedId)

            gameLibraryRepository.updateAnalysisState(
                gameId = game.id,
                status = AnalysisStatus.COMPLETED,
                summary = "${allVariables.size} var(s) • ${limitations.count { it.severity == "ALTA" }} alerta(s) online",
                analysisId = savedId
            )
            auditLogDao.insert(
                AuditLogEntity(
                    category = "ANALYSIS",
                    message = "Análise concluída para ${game.name}: ${allVariables.size} variáveis catalogadas.",
                    timestamp = now
                )
            )

            for (i in steps.indices) {
                steps[i] = steps[i].copy(completed = true, active = false)
            }
            emit(AnalysisPipelineEvent.Progress(steps.toList()))
            emit(AnalysisPipelineEvent.Finished(finalReport))
        } catch (e: Exception) {
            gameLibraryRepository.updateAnalysisState(game.id, AnalysisStatus.FAILED)
            auditLogDao.insert(
                AuditLogEntity(
                    category = "ERROR",
                    message = "Erro ao analisar ${game.name}: ${e.localizedMessage ?: "falha desconhecida"}",
                    timestamp = System.currentTimeMillis()
                )
            )
            emit(AnalysisPipelineEvent.Failed(e.localizedMessage ?: "Falha na análise técnica do APK."))
        }
    }.flowOn(Dispatchers.IO)

    fun analyzeInstalledApp(
        installedApp: InstalledAppInfo,
        settings: AppSettings
    ): Flow<AnalysisPipelineEvent> = flow {
        val steps = stepTitles.mapIndexed { idx, title ->
            AnalysisStep(index = idx, title = title, active = idx == 0)
        }.toMutableList()

        suspend fun emitStep(activeIndex: Int, detail: String = "") {
            for (i in steps.indices) {
                steps[i] = steps[i].copy(
                    completed = i < activeIndex,
                    active = i == activeIndex,
                    detail = if (i == activeIndex) detail else steps[i].detail
                )
            }
            emit(AnalysisPipelineEvent.Progress(steps.toList()))
        }

        try {
            emitStep(0, "Preparando inspeção via PackageManager para ${installedApp.packageName}...")

            val sourceFile = installedApp.sourceDir?.let { File(it) }?.takeIf { it.exists() && it.canRead() }
            if (sourceFile != null) {
                emitStep(1, "Validando APK instalado somente-leitura...")
                val outcome = metadataExtractor.extractFromValidatedFile(
                    apkFile = sourceFile,
                    fallbackName = installedApp.name,
                    sourceUri = sourceFile.absolutePath,
                    maxEntries = settings.maxZipEntries,
                    deepDexScan = settings.deepDexScanEnabled
                ).getOrElse { throw it }

                emitStep(2, "Pacote ${outcome.metadata.packageName} v${outcome.metadata.versionName}")
                emitStep(3, "${outcome.scanFindings.entryCount} entradas inspecionadas")
                emitStep(4, "${outcome.metadata.dexFiles.size} DEX encontrados")

                val vars = variableDetector.detectFromTokens(outcome.scanFindings.tokens)
                emitStep(5, "${vars.count { it.category == "Pontuação" }} referência(s) de pontuação")
                emitStep(6, "${vars.count { it.category == "Economia" }} referência(s) de economia")
                emitStep(7, "${vars.count { it.category == "Sobrevivência" || it.category == "Energia" }} referência(s) de vidas/energia")

                emitStep(8, "Gerando relatório técnico...")
                val limits = onlineLimitationAnalyzer.analyze(outcome.metadata, outcome.scanFindings.tokens)
                val ai = aiEngine.interpretTechnicalData(outcome.metadata, vars, limits)
                val now = System.currentTimeMillis()
                val text = buildTechnicalReportText(outcome.metadata, vars, limits, outcome.warnings, ai.summary, ai.noticeBanner)
                val draft = AnalysisReport(
                    gameId = null,
                    gameName = installedApp.name,
                    packageName = installedApp.packageName,
                    analyzedAt = now,
                    metadata = outcome.metadata,
                    variables = vars,
                    onlineLimitations = limits,
                    aiInterpretation = ai,
                    errorsFound = outcome.warnings,
                    fullTechnicalReportText = text
                )
                val savedId = historyRepository.saveReport(draft)
                for (i in steps.indices) {
                    steps[i] = steps[i].copy(completed = true, active = false)
                }
                emit(AnalysisPipelineEvent.Progress(steps.toList()))
                emit(AnalysisPipelineEvent.Finished(draft.copy(id = savedId)))
            } else {
                // Package visibility metadata-only fallback (respecting Android sandboxing)
                emitStep(1, "APK base protegido pelo sistema; inspecionando metadados públicos permitidos...")
                emitStep(2, "Nome: ${installedApp.name} • Versão ${installedApp.versionName}")
                emitStep(3, "Acesso direto a dados privados bloqueado pelo sandbox Android.")
                emitStep(4, "Tipo: ${installedApp.appTypeLabel}")
                emitStep(5, "Sem acesso ao DEX interno sem exportação do APK.")
                emitStep(6, "Sem acesso a assets privados.")
                emitStep(7, "Sem acesso a preferências privadas de terceiros.")
                emitStep(8, "Gerando relatório de metadados públicos...")

                val meta = ApkTechnicalMetadata(
                    appName = installedApp.name,
                    packageName = installedApp.packageName,
                    versionName = installedApp.versionName,
                    versionCode = installedApp.versionCode,
                    sizeBytes = 0L,
                    sha256 = "N/D (sandbox do sistema)",
                    minSdk = null,
                    targetSdk = null,
                    entryCount = 0,
                    dexFiles = emptyList(),
                    nativeAbis = emptyList(),
                    permissions = emptyList(),
                    activitiesCount = 0,
                    servicesCount = 0,
                    receiversCount = 0,
                    configFiles = emptyList(),
                    isDebuggable = false,
                    usesCleartextTraffic = false,
                    hasOnlinePermissions = true
                )
                val emptyScan = ApkScanFindings(0, emptyList(), emptyList(), emptyList(), emptyList(), emptyList())
                val limits = onlineLimitationAnalyzer.analyze(meta, emptyScan.tokens)
                val ai = aiEngine.interpretTechnicalData(meta, emptyList(), limits)
                val warnings = listOf(
                    "O Android impede leitura direta de dados privados e binários protegidos de outros aplicativos. Para análise estrutural completa, importe o arquivo APK via ADICIONAR APK."
                )
                val now = System.currentTimeMillis()
                val text = buildTechnicalReportText(meta, emptyList(), limits, warnings, ai.summary, ai.noticeBanner)
                val draft = AnalysisReport(
                    gameId = null,
                    gameName = installedApp.name,
                    packageName = installedApp.packageName,
                    analyzedAt = now,
                    metadata = meta,
                    variables = emptyList(),
                    onlineLimitations = limits,
                    aiInterpretation = ai,
                    errorsFound = warnings,
                    fullTechnicalReportText = text
                )
                val savedId = historyRepository.saveReport(draft)
                for (i in steps.indices) {
                    steps[i] = steps[i].copy(completed = true, active = false)
                }
                emit(AnalysisPipelineEvent.Progress(steps.toList()))
                emit(AnalysisPipelineEvent.Finished(draft.copy(id = savedId)))
            }
        } catch (e: Exception) {
            emit(AnalysisPipelineEvent.Failed(e.localizedMessage ?: "Falha ao analisar aplicativo instalado."))
        }
    }.flowOn(Dispatchers.IO)

    private fun buildTechnicalReportText(
        metadata: ApkTechnicalMetadata,
        variables: List<com.example.domain.DetectedVariable>,
        limitations: List<com.example.domain.OnlineLimitation>,
        warnings: List<String>,
        aiSummary: String,
        aiNotice: String
    ): String = buildString {
        appendLine("=== RELATÓRIO TÉCNICO - GAME HACKER AI MASTER ===")
        appendLine("Aplicativo: ${metadata.appName}")
        appendLine("Pacote: ${metadata.packageName}")
        appendLine("Versão: ${metadata.versionName} (code ${metadata.versionCode})")
        appendLine("SHA-256: ${metadata.sha256}")
        appendLine("Entradas ZIP: ${metadata.entryCount} | DEX: ${metadata.dexFiles.size} | ABIs: ${metadata.nativeAbis.joinToString().ifBlank { "Dalvik/ART" }}")
        appendLine()
        appendLine("--- INTERPRETAÇÃO DO MOTOR DE ANÁLISE ---")
        appendLine(aiNotice)
        appendLine(aiSummary)
        appendLine()
        appendLine("--- VARIÁVEIS / REFERÊNCIAS IDENTIFICADAS (${variables.size}) ---")
        if (variables.isEmpty()) {
            appendLine("Nenhuma referência compatível encontrada na varredura.")
        } else {
            variables.forEach { v ->
                appendLine("• [${v.status.label}] ${v.name} (${v.confidencePercent}%) - ${v.technicalLocation}")
                appendLine("  Evidência: ${v.evidence} | Tipo: ${v.dataType}")
                appendLine("  Nota: ${v.epistemicNote}")
            }
        }
        appendLine()
        appendLine("--- LIMITAÇÕES ONLINE E SEGURANÇA (${limitations.size}) ---")
        limitations.forEach { l ->
            appendLine("• [${l.severity}] ${l.title}: ${l.explanation}")
        }
        if (warnings.isNotEmpty()) {
            appendLine()
            appendLine("--- AVISOS / LIMITAÇÕES ---")
            warnings.forEach { appendLine("• $it") }
        }
    }
}
