package com.example.data

import com.example.domain.AiInterpretationResult
import com.example.domain.AnalysisReport
import com.example.domain.ApkTechnicalMetadata
import com.example.domain.DetectionStatus
import com.example.domain.DetectedVariable
import com.example.domain.OnlineLimitation
import com.example.domain.TechnicalOrigin
import org.json.JSONArray
import org.json.JSONObject

object AnalysisReportSerializer {

    fun toJson(report: AnalysisReport): String {
        val root = JSONObject()
        root.put("gameId", report.gameId ?: JSONObject.NULL)
        root.put("gameName", report.gameName)
        root.put("packageName", report.packageName)
        root.put("analyzedAt", report.analyzedAt)
        root.put("fullTechnicalReportText", report.fullTechnicalReportText)

        val metaJson = JSONObject().apply {
            put("appName", report.metadata.appName)
            put("packageName", report.metadata.packageName)
            put("versionName", report.metadata.versionName)
            put("versionCode", report.metadata.versionCode)
            put("sizeBytes", report.metadata.sizeBytes)
            put("sha256", report.metadata.sha256)
            put("minSdk", report.metadata.minSdk ?: JSONObject.NULL)
            put("targetSdk", report.metadata.targetSdk ?: JSONObject.NULL)
            put("entryCount", report.metadata.entryCount)
            put("dexFiles", JSONArray(report.metadata.dexFiles))
            put("nativeAbis", JSONArray(report.metadata.nativeAbis))
            put("permissions", JSONArray(report.metadata.permissions))
            put("activitiesCount", report.metadata.activitiesCount)
            put("servicesCount", report.metadata.servicesCount)
            put("receiversCount", report.metadata.receiversCount)
            put("configFiles", JSONArray(report.metadata.configFiles))
            put("isDebuggable", report.metadata.isDebuggable)
            put("usesCleartextTraffic", report.metadata.usesCleartextTraffic)
            put("hasOnlinePermissions", report.metadata.hasOnlinePermissions)
        }
        root.put("metadata", metaJson)

        val varsArray = JSONArray()
        report.variables.forEach { v ->
            varsArray.put(
                JSONObject().apply {
                    put("name", v.name)
                    put("category", v.category)
                    put("technicalLocation", v.technicalLocation)
                    put("dataType", v.dataType)
                    put("evidence", v.evidence)
                    put("confidencePercent", v.confidencePercent)
                    put("origin", v.origin.name)
                    put("status", v.status.name)
                    put("epistemicNote", v.epistemicNote)
                }
            )
        }
        root.put("variables", varsArray)

        val limitsArray = JSONArray()
        report.onlineLimitations.forEach { l ->
            limitsArray.put(
                JSONObject().apply {
                    put("title", l.title)
                    put("category", l.category)
                    put("severity", l.severity)
                    put("evidence", l.evidence)
                    put("explanation", l.explanation)
                    put("officialApiNote", l.officialApiNote)
                }
            )
        }
        root.put("onlineLimitations", limitsArray)

        val aiJson = JSONObject().apply {
            put("engineMode", report.aiInterpretation.engineMode)
            put("isCloudAiActive", report.aiInterpretation.isCloudAiActive)
            put("noticeBanner", report.aiInterpretation.noticeBanner)
            put("summary", report.aiInterpretation.summary)
            put("architectureAssessment", report.aiInterpretation.architectureAssessment)
            put("onlineRestrictionsSummary", report.aiInterpretation.onlineRestrictionsSummary)
            put("recommendations", JSONArray(report.aiInterpretation.recommendations))
        }
        root.put("aiInterpretation", aiJson)
        root.put("errorsFound", JSONArray(report.errorsFound))

        return root.toString()
    }

    fun fromJson(id: Long, jsonString: String): AnalysisReport {
        val root = JSONObject(jsonString)
        val metaJson = root.getJSONObject("metadata")
        val metadata = ApkTechnicalMetadata(
            appName = metaJson.optString("appName"),
            packageName = metaJson.optString("packageName"),
            versionName = metaJson.optString("versionName"),
            versionCode = metaJson.optLong("versionCode"),
            sizeBytes = metaJson.optLong("sizeBytes"),
            sha256 = metaJson.optString("sha256"),
            minSdk = if (metaJson.isNull("minSdk")) null else metaJson.optInt("minSdk"),
            targetSdk = if (metaJson.isNull("targetSdk")) null else metaJson.optInt("targetSdk"),
            entryCount = metaJson.optInt("entryCount"),
            dexFiles = metaJson.optJSONArray("dexFiles").toStringList(),
            nativeAbis = metaJson.optJSONArray("nativeAbis").toStringList(),
            permissions = metaJson.optJSONArray("permissions").toStringList(),
            activitiesCount = metaJson.optInt("activitiesCount"),
            servicesCount = metaJson.optInt("servicesCount"),
            receiversCount = metaJson.optInt("receiversCount"),
            configFiles = metaJson.optJSONArray("configFiles").toStringList(),
            isDebuggable = metaJson.optBoolean("isDebuggable"),
            usesCleartextTraffic = metaJson.optBoolean("usesCleartextTraffic"),
            hasOnlinePermissions = metaJson.optBoolean("hasOnlinePermissions")
        )

        val varsArr = root.optJSONArray("variables") ?: JSONArray()
        val variables = (0 until varsArr.length()).map { idx ->
            val obj = varsArr.getJSONObject(idx)
            DetectedVariable(
                name = obj.optString("name"),
                category = obj.optString("category"),
                technicalLocation = obj.optString("technicalLocation"),
                dataType = obj.optString("dataType"),
                evidence = obj.optString("evidence"),
                confidencePercent = obj.optInt("confidencePercent"),
                origin = runCatching { TechnicalOrigin.valueOf(obj.optString("origin")) }
                    .getOrDefault(TechnicalOrigin.RESOURCE_UI),
                status = runCatching { DetectionStatus.valueOf(obj.optString("status")) }
                    .getOrDefault(DetectionStatus.IDENTIFICADO),
                epistemicNote = obj.optString("epistemicNote")
            )
        }

        val limitsArr = root.optJSONArray("onlineLimitations") ?: JSONArray()
        val limitations = (0 until limitsArr.length()).map { idx ->
            val obj = limitsArr.getJSONObject(idx)
            OnlineLimitation(
                title = obj.optString("title"),
                category = obj.optString("category"),
                severity = obj.optString("severity"),
                evidence = obj.optString("evidence"),
                explanation = obj.optString("explanation"),
                officialApiNote = obj.optString("officialApiNote")
            )
        }

        val aiJson = root.getJSONObject("aiInterpretation")
        val ai = AiInterpretationResult(
            engineMode = aiJson.optString("engineMode"),
            isCloudAiActive = aiJson.optBoolean("isCloudAiActive"),
            noticeBanner = aiJson.optString("noticeBanner"),
            summary = aiJson.optString("summary"),
            architectureAssessment = aiJson.optString("architectureAssessment"),
            onlineRestrictionsSummary = aiJson.optString("onlineRestrictionsSummary"),
            recommendations = aiJson.optJSONArray("recommendations").toStringList()
        )

        return AnalysisReport(
            id = id,
            gameId = if (root.isNull("gameId")) null else root.optLong("gameId"),
            gameName = root.optString("gameName"),
            packageName = root.optString("packageName"),
            analyzedAt = root.optLong("analyzedAt"),
            metadata = metadata,
            variables = variables,
            onlineLimitations = limitations,
            aiInterpretation = ai,
            errorsFound = root.optJSONArray("errorsFound").toStringList(),
            fullTechnicalReportText = root.optString("fullTechnicalReportText")
        )
    }

    private fun JSONArray?.toStringList(): List<String> {
        if (this == null) return emptyList()
        return (0 until length()).map { getString(it) }
    }
}
