package com.example.data

import android.content.Context
import android.net.Uri
import com.example.data.db.AuditLogDao
import com.example.data.db.AuditLogEntity
import com.example.data.db.AuthorizedEditorDao
import com.example.data.db.AuthorizedProfileEntity
import com.example.data.db.ValueBackupEntity
import com.example.data.db.ValueChangeLogEntity
import com.example.domain.AuthorizedGameProfile
import com.example.domain.ValueBackupSnapshot
import com.example.domain.ValueChangeLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONObject

data class EditorValuesInput(
    val score: Int,
    val coins: Int,
    val lives: Int,
    val energy: Int,
    val xp: Int,
    val level: Int
)

class AuthorizedEditorRepository(
    private val context: Context,
    private val editorDao: AuthorizedEditorDao,
    private val auditLogDao: AuditLogDao
) {
    val profilesFlow: Flow<List<AuthorizedGameProfile>> = editorDao.observeProfiles().map { list ->
        list.map { it.toDomain() }
    }

    fun observeBackups(profileId: Long): Flow<List<ValueBackupSnapshot>> =
        editorDao.observeBackups(profileId).map { list -> list.map { it.toDomain() } }

    fun observeChangeLogs(profileId: Long): Flow<List<ValueChangeLog>> =
        editorDao.observeChangeLogs(profileId).map { list -> list.map { it.toDomain() } }

    suspend fun ensureDefaultAuthorizedProfile() = withContext(Dispatchers.IO) {
        if (editorDao.countProfiles() == 0) {
            val now = System.currentTimeMillis()
            val id = editorDao.insertProfile(
                AuthorizedProfileEntity(
                    gameName = "Meu jogo de teste",
                    packageName = "com.aistudio.sandbox.testgame",
                    isAuthorizedOwnGame = true,
                    authorizationSource = "LOCAL_SANDBOX",
                    externalUri = null,
                    score = 500,
                    coins = 100,
                    lives = 3,
                    energy = 100,
                    xp = 250,
                    level = 5,
                    updatedAt = now
                )
            )
            editorDao.insertBackup(
                ValueBackupEntity(
                    profileId = id,
                    gameName = "Meu jogo de teste",
                    score = 500,
                    coins = 100,
                    lives = 3,
                    energy = 100,
                    xp = 250,
                    level = 5,
                    reason = "Snapshot inicial de fábrica",
                    createdAt = now
                )
            )
        }
    }

    suspend fun importAuthorizedJsonProfile(uri: Uri): Result<AuthorizedGameProfile> = withContext(Dispatchers.IO) {
        return@withContext try {
            val rawText = context.contentResolver.openInputStream(uri)?.use { stream ->
                stream.bufferedReader().readText()
            } ?: return@withContext Result.failure(IllegalStateException("Não foi possível ler o arquivo JSON selecionado."))

            val json = JSONObject(rawText)
            val authorizedFlag = json.optBoolean("authorizedEdit", true)
            if (!authorizedFlag) {
                return@withContext Result.failure(
                    SecurityException("O arquivo declara authorizedEdit=false. Edição recusada.")
                )
            }
            val now = System.currentTimeMillis()
            val gameName = json.optString("gameName", "Jogo Próprio JSON").ifBlank { "Jogo Próprio JSON" }
            val packageName = json.optString("packageName", "com.custom.authorized.game")
            val entity = AuthorizedProfileEntity(
                gameName = gameName,
                packageName = packageName,
                isAuthorizedOwnGame = true,
                authorizationSource = "AUTHORIZED_SAF_JSON",
                externalUri = uri.toString(),
                score = json.optInt("score", 0).coerceIn(0, MAX_ALLOWED_VALUE),
                coins = json.optInt("coins", 0).coerceIn(0, MAX_ALLOWED_VALUE),
                lives = json.optInt("lives", 3).coerceIn(0, MAX_LIVES_VALUE),
                energy = json.optInt("energy", 100).coerceIn(0, MAX_ALLOWED_VALUE),
                xp = json.optInt("xp", 0).coerceIn(0, MAX_ALLOWED_VALUE),
                level = json.optInt("level", 1).coerceIn(1, MAX_LEVEL_VALUE),
                updatedAt = now
            )
            val id = editorDao.insertProfile(entity)
            editorDao.insertBackup(
                ValueBackupEntity(
                    profileId = id,
                    gameName = gameName,
                    score = entity.score,
                    coins = entity.coins,
                    lives = entity.lives,
                    energy = entity.energy,
                    xp = entity.xp,
                    level = entity.level,
                    reason = "Backup automático na importação JSON",
                    createdAt = now
                )
            )
            auditLogDao.insert(
                AuditLogEntity(category = "EDITOR", message = "Perfil autorizado importado via SAF: $gameName", timestamp = now)
            )
            Result.success(entity.copy(id = id).toDomain())
        } catch (e: Exception) {
            Result.failure(IllegalArgumentException("JSON inválido para perfil de jogo autorizado: ${e.localizedMessage}"))
        }
    }

    suspend fun exportProfileToJsonUri(profileId: Long, uri: Uri): Result<Unit> = withContext(Dispatchers.IO) {
        return@withContext try {
            val profile = editorDao.getProfileById(profileId)
                ?: return@withContext Result.failure(IllegalStateException("Perfil não encontrado."))
            val json = JSONObject().apply {
                put("gameName", profile.gameName)
                put("packageName", profile.packageName)
                put("authorizedEdit", profile.isAuthorizedOwnGame)
                put("score", profile.score)
                put("coins", profile.coins)
                put("lives", profile.lives)
                put("energy", profile.energy)
                put("xp", profile.xp)
                put("level", profile.level)
                put("updatedAt", profile.updatedAt)
            }
            context.contentResolver.openOutputStream(uri)?.use { out ->
                out.write(json.toString(2).toByteArray(Charsets.UTF_8))
            } ?: return@withContext Result.failure(IllegalStateException("Falha ao abrir destino de exportação."))
            auditLogDao.insert(
                AuditLogEntity(category = "BACKUP", message = "Backup JSON exportado para ${profile.gameName}", timestamp = System.currentTimeMillis())
            )
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun validateInput(input: EditorValuesInput): String? {
        return when {
            input.score < 0 || input.score > MAX_ALLOWED_VALUE -> "Pontuação deve estar entre 0 e $MAX_ALLOWED_VALUE."
            input.coins < 0 || input.coins > MAX_ALLOWED_VALUE -> "Moedas devem estar entre 0 e $MAX_ALLOWED_VALUE."
            input.lives < 0 || input.lives > MAX_LIVES_VALUE -> "Vidas devem estar entre 0 e $MAX_LIVES_VALUE."
            input.energy < 0 || input.energy > MAX_ALLOWED_VALUE -> "Energia deve estar entre 0 e $MAX_ALLOWED_VALUE."
            input.xp < 0 || input.xp > MAX_ALLOWED_VALUE -> "XP deve estar entre 0 e $MAX_ALLOWED_VALUE."
            input.level < 1 || input.level > MAX_LEVEL_VALUE -> "Nível deve estar entre 1 e $MAX_LEVEL_VALUE."
            else -> null
        }
    }

    suspend fun applyChanges(
        profileId: Long,
        newValues: EditorValuesInput,
        createAutoBackup: Boolean = true
    ): Result<AuthorizedGameProfile> = withContext(Dispatchers.IO) {
        val current = editorDao.getProfileById(profileId)
            ?: return@withContext Result.failure(IllegalArgumentException("Perfil autorizado não encontrado."))

        if (!current.isAuthorizedOwnGame) {
            return@withContext Result.failure(
                SecurityException("Operação bloqueada: não é permitido modificar dados protegidos de jogos de terceiros.")
            )
        }

        validateInput(newValues)?.let { err ->
            return@withContext Result.failure(IllegalArgumentException(err))
        }

        val now = System.currentTimeMillis()
        if (createAutoBackup) {
            editorDao.insertBackup(
                ValueBackupEntity(
                    profileId = current.id,
                    gameName = current.gameName,
                    score = current.score,
                    coins = current.coins,
                    lives = current.lives,
                    energy = current.energy,
                    xp = current.xp,
                    level = current.level,
                    reason = "Backup pré-edição automático",
                    createdAt = now
                )
            )
        }

        val updated = current.copy(
            score = newValues.score,
            coins = newValues.coins,
            lives = newValues.lives,
            energy = newValues.energy,
            xp = newValues.xp,
            level = newValues.level,
            updatedAt = now
        )
        editorDao.updateProfile(updated)

        logDiff(current.id, "Pontuação", current.score, newValues.score, now)
        logDiff(current.id, "Moedas", current.coins, newValues.coins, now)
        logDiff(current.id, "Vidas", current.lives, newValues.lives, now)
        logDiff(current.id, "Energia", current.energy, newValues.energy, now)
        logDiff(current.id, "XP", current.xp, newValues.xp, now)
        logDiff(current.id, "Nível", current.level, newValues.level, now)

        // If backed by a SAF JSON file with persistable/writable URI, attempt sync write back
        current.externalUri?.let { uriStr ->
            runCatching {
                val uri = Uri.parse(uriStr)
                exportProfileToJsonUri(current.id, uri)
            }
        }

        auditLogDao.insert(
            AuditLogEntity(category = "EDITOR", message = "Valores atualizados em ${current.gameName} (autorizado)", timestamp = now)
        )
        Result.success(updated.toDomain())
    }

    suspend fun createManualBackup(profileId: Long, reason: String = "Backup manual"): Result<Unit> =
        withContext(Dispatchers.IO) {
            val current = editorDao.getProfileById(profileId)
                ?: return@withContext Result.failure(IllegalArgumentException("Perfil não encontrado."))
            val now = System.currentTimeMillis()
            editorDao.insertBackup(
                ValueBackupEntity(
                    profileId = current.id,
                    gameName = current.gameName,
                    score = current.score,
                    coins = current.coins,
                    lives = current.lives,
                    energy = current.energy,
                    xp = current.xp,
                    level = current.level,
                    reason = reason,
                    createdAt = now
                )
            )
            auditLogDao.insert(AuditLogEntity(category = "BACKUP", message = "Snapshot criado para ${current.gameName}", timestamp = now))
            Result.success(Unit)
        }

    suspend fun restoreFromBackup(backupId: Long): Result<AuthorizedGameProfile> = withContext(Dispatchers.IO) {
        val backup = editorDao.getBackupById(backupId)
            ?: return@withContext Result.failure(IllegalArgumentException("Backup não encontrado."))
        val current = editorDao.getProfileById(backup.profileId)
            ?: return@withContext Result.failure(IllegalArgumentException("Perfil não encontrado."))

        val now = System.currentTimeMillis()
        val restored = current.copy(
            score = backup.score,
            coins = backup.coins,
            lives = backup.lives,
            energy = backup.energy,
            xp = backup.xp,
            level = backup.level,
            updatedAt = now
        )
        editorDao.updateProfile(restored)
        editorDao.insertChangeLog(
            ValueChangeLogEntity(
                profileId = current.id,
                fieldChanged = "Restauração Completa",
                oldValue = "Score=${current.score}, Moedas=${current.coins}, Vidas=${current.lives}",
                newValue = "Score=${backup.score}, Moedas=${backup.coins}, Vidas=${backup.lives}",
                status = "RESTORED",
                timestamp = now
            )
        )
        auditLogDao.insert(AuditLogEntity(category = "BACKUP", message = "Perfil ${current.gameName} restaurado de snapshot #$backupId", timestamp = now))
        Result.success(restored.toDomain())
    }

    private suspend fun logDiff(profileId: Long, field: String, oldVal: Int, newVal: Int, timestamp: Long) {
        if (oldVal != newVal) {
            editorDao.insertChangeLog(
                ValueChangeLogEntity(
                    profileId = profileId,
                    fieldChanged = field,
                    oldValue = oldVal.toString(),
                    newValue = newVal.toString(),
                    status = "APPLIED",
                    timestamp = timestamp
                )
            )
        }
    }

    private fun AuthorizedProfileEntity.toDomain() = AuthorizedGameProfile(
        id = id,
        gameName = gameName,
        packageName = packageName,
        isAuthorizedOwnGame = isAuthorizedOwnGame,
        authorizationSource = authorizationSource,
        externalUri = externalUri,
        score = score,
        coins = coins,
        lives = lives,
        energy = energy,
        xp = xp,
        level = level,
        updatedAt = updatedAt
    )

    private fun ValueBackupEntity.toDomain() = ValueBackupSnapshot(
        id = id,
        profileId = profileId,
        gameName = gameName,
        score = score,
        coins = coins,
        lives = lives,
        energy = energy,
        xp = xp,
        level = level,
        reason = reason,
        createdAt = createdAt
    )

    private fun ValueChangeLogEntity.toDomain() = ValueChangeLog(
        id = id,
        profileId = profileId,
        fieldChanged = fieldChanged,
        oldValue = oldValue,
        newValue = newValue,
        status = status,
        timestamp = timestamp
    )

    companion object {
        const val MAX_ALLOWED_VALUE = 999_999_999
        const val MAX_LIVES_VALUE = 999
        const val MAX_LEVEL_VALUE = 9999
    }
}
