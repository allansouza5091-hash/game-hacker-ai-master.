package com.example.data

import android.net.Uri
import com.example.analysis.ApkImportOutcome
import com.example.analysis.ApkMetadataExtractor
import com.example.data.db.AuditLogDao
import com.example.data.db.AuditLogEntity
import com.example.data.db.GameDao
import com.example.data.db.GameEntity
import com.example.domain.AnalysisStatus
import com.example.domain.GameRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File

class GameLibraryRepository(
    private val gameDao: GameDao,
    private val auditLogDao: AuditLogDao,
    private val metadataExtractor: ApkMetadataExtractor
) {
    val gamesFlow: Flow<List<GameRecord>> = gameDao.observeAllGames().map { list ->
        list.map { it.toDomain() }
    }

    suspend fun importApkFromUri(
        uri: Uri,
        maxSizeMb: Int,
        maxEntries: Int,
        deepDexScan: Boolean
    ): Result<Pair<GameRecord, ApkImportOutcome>> = withContext(Dispatchers.IO) {
        val extractionResult = metadataExtractor.importAndExtractFromUri(
            uri = uri,
            maxSizeMb = maxSizeMb,
            maxEntries = maxEntries,
            deepDexScan = deepDexScan
        )

        extractionResult.fold(
            onSuccess = { outcome ->
                val meta = outcome.metadata
                val existing = gameDao.getBySha256(meta.sha256)
                val entity = GameEntity(
                    id = existing?.id ?: 0L,
                    name = meta.appName,
                    packageName = meta.packageName,
                    versionName = meta.versionName,
                    versionCode = meta.versionCode,
                    sizeBytes = meta.sizeBytes,
                    sourceUri = outcome.sourceUri,
                    cachedApkPath = outcome.cachedApkPath,
                    iconPath = outcome.iconPath,
                    sha256 = meta.sha256,
                    importedAt = System.currentTimeMillis(),
                    analysisStatus = existing?.analysisStatus ?: AnalysisStatus.NOT_ANALYZED.name,
                    lastReportSummary = existing?.lastReportSummary,
                    lastAnalysisId = existing?.lastAnalysisId
                )
                val insertedId = gameDao.insertGame(entity)
                auditLogDao.insert(
                    AuditLogEntity(
                        category = "IMPORT",
                        message = "APK importado e validado: ${meta.appName} (${meta.packageName} v${meta.versionName})",
                        timestamp = System.currentTimeMillis()
                    )
                )
                Result.success(entity.copy(id = insertedId).toDomain() to outcome)
            },
            onFailure = { error ->
                auditLogDao.insert(
                    AuditLogEntity(
                        category = "SECURITY",
                        message = "Falha na importação/validação de APK: ${error.localizedMessage ?: "erro desconhecido"}",
                        timestamp = System.currentTimeMillis()
                    )
                )
                Result.failure(error)
            }
        )
    }

    suspend fun getById(id: Long): GameRecord? = withContext(Dispatchers.IO) {
        gameDao.getById(id)?.toDomain()
    }

    suspend fun updateAnalysisState(
        gameId: Long,
        status: AnalysisStatus,
        summary: String? = null,
        analysisId: Long? = null
    ) = withContext(Dispatchers.IO) {
        val current = gameDao.getById(gameId) ?: return@withContext
        gameDao.updateGame(
            current.copy(
                analysisStatus = status.name,
                lastReportSummary = summary ?: current.lastReportSummary,
                lastAnalysisId = analysisId ?: current.lastAnalysisId
            )
        )
    }

    suspend fun removeFromLibrary(gameId: Long, deleteCachedCopy: Boolean = false) = withContext(Dispatchers.IO) {
        val current = gameDao.getById(gameId) ?: return@withContext
        if (deleteCachedCopy) {
            current.cachedApkPath?.let { path -> runCatching { File(path).delete() } }
            current.iconPath?.let { path -> runCatching { File(path).delete() } }
        }
        gameDao.deleteById(gameId)
        auditLogDao.insert(
            AuditLogEntity(
                category = "IMPORT",
                message = "Removido da biblioteca interna: ${current.name} (arquivo original preservado).",
                timestamp = System.currentTimeMillis()
            )
        )
    }

    private fun GameEntity.toDomain(): GameRecord = GameRecord(
        id = id,
        name = name,
        packageName = packageName,
        versionName = versionName,
        versionCode = versionCode,
        sizeBytes = sizeBytes,
        sourceUri = sourceUri,
        cachedApkPath = cachedApkPath,
        iconPath = iconPath,
        sha256 = sha256,
        importedAt = importedAt,
        analysisStatus = runCatching { AnalysisStatus.valueOf(analysisStatus) }
            .getOrDefault(AnalysisStatus.NOT_ANALYZED),
        lastReportSummary = lastReportSummary,
        lastAnalysisId = lastAnalysisId
    )
}
