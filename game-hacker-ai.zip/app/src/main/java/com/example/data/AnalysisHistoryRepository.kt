package com.example.data

import com.example.data.db.AnalysisHistoryDao
import com.example.data.db.AnalysisHistoryEntity
import com.example.domain.AnalysisReport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

data class HistorySummaryItem(
    val id: Long,
    val gameId: Long?,
    val gameName: String,
    val packageName: String,
    val analyzedAt: Long,
    val resultSummary: String,
    val variablesCount: Int,
    val errorsCount: Int
)

class AnalysisHistoryRepository(
    private val historyDao: AnalysisHistoryDao
) {
    val historyItemsFlow: Flow<List<HistorySummaryItem>> = historyDao.observeAll().map { list ->
        list.map { it.toSummary() }
    }

    val latestHistoryItemFlow: Flow<HistorySummaryItem?> = historyDao.observeLatest().map {
        it?.toSummary()
    }

    suspend fun saveReport(report: AnalysisReport): Long = withContext(Dispatchers.IO) {
        val payload = AnalysisReportSerializer.toJson(report)
        val summary = buildString {
            append("${report.variables.size} var(s) • ")
            append("${report.onlineLimitations.count { it.severity == "ALTA" }} restrição(ões) alta(s)")
        }
        val entity = AnalysisHistoryEntity(
            gameId = report.gameId,
            gameName = report.gameName,
            packageName = report.packageName,
            analyzedAt = report.analyzedAt,
            resultSummary = summary,
            variablesCount = report.variables.size,
            errorsCount = report.errorsFound.size,
            reportPayloadJson = payload
        )
        historyDao.insert(entity)
    }

    suspend fun getFullReport(reportId: Long): AnalysisReport? = withContext(Dispatchers.IO) {
        val entity = historyDao.getById(reportId) ?: return@withContext null
        runCatching { AnalysisReportSerializer.fromJson(entity.id, entity.reportPayloadJson) }.getOrNull()
    }

    suspend fun deleteReport(reportId: Long) = withContext(Dispatchers.IO) {
        historyDao.deleteById(reportId)
    }

    private fun AnalysisHistoryEntity.toSummary(): HistorySummaryItem = HistorySummaryItem(
        id = id,
        gameId = gameId,
        gameName = gameName,
        packageName = packageName,
        analyzedAt = analyzedAt,
        resultSummary = resultSummary,
        variablesCount = variablesCount,
        errorsCount = errorsCount
    )
}
