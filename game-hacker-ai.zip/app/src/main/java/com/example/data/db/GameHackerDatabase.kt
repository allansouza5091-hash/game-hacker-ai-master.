package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        GameEntity::class,
        AnalysisHistoryEntity::class,
        AuthorizedProfileEntity::class,
        ValueBackupEntity::class,
        ValueChangeLogEntity::class,
        AuditLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class GameHackerDatabase : RoomDatabase() {
    abstract fun gameDao(): GameDao
    abstract fun analysisHistoryDao(): AnalysisHistoryDao
    abstract fun authorizedEditorDao(): AuthorizedEditorDao
    abstract fun auditLogDao(): AuditLogDao

    companion object {
        @Volatile
        private var INSTANCE: GameHackerDatabase? = null

        fun getInstance(context: Context): GameHackerDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    GameHackerDatabase::class.java,
                    "game_hacker_ai_master.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
