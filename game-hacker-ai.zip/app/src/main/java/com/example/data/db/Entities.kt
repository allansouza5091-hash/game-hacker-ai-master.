package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "games")
data class GameEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val sizeBytes: Long,
    val sourceUri: String?,
    val cachedApkPath: String?,
    val iconPath: String?,
    val sha256: String,
    val importedAt: Long,
    val analysisStatus: String,
    val lastReportSummary: String?,
    val lastAnalysisId: Long?
)

@Entity(tableName = "analysis_history")
data class AnalysisHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val gameId: Long?,
    val gameName: String,
    val packageName: String,
    val analyzedAt: Long,
    val resultSummary: String,
    val variablesCount: Int,
    val errorsCount: Int,
    val reportPayloadJson: String
)

@Entity(tableName = "authorized_profiles")
data class AuthorizedProfileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val gameName: String,
    val packageName: String,
    val isAuthorizedOwnGame: Boolean,
    val authorizationSource: String,
    val externalUri: String?,
    val score: Int,
    val coins: Int,
    val lives: Int,
    val energy: Int,
    val xp: Int,
    val level: Int,
    val updatedAt: Long
)

@Entity(tableName = "value_backups")
data class ValueBackupEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: Long,
    val gameName: String,
    val score: Int,
    val coins: Int,
    val lives: Int,
    val energy: Int,
    val xp: Int,
    val level: Int,
    val reason: String,
    val createdAt: Long
)

@Entity(tableName = "value_change_logs")
data class ValueChangeLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: Long,
    val fieldChanged: String,
    val oldValue: String,
    val newValue: String,
    val status: String,
    val timestamp: Long
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String,
    val message: String,
    val timestamp: Long
)
