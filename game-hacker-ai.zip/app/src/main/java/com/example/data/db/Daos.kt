package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface GameDao {
    @Query("SELECT * FROM games ORDER BY importedAt DESC")
    fun observeAllGames(): Flow<List<GameEntity>>

    @Query("SELECT * FROM games WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): GameEntity?

    @Query("SELECT * FROM games WHERE sha256 = :sha256 LIMIT 1")
    suspend fun getBySha256(sha256: String): GameEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGame(game: GameEntity): Long

    @Update
    suspend fun updateGame(game: GameEntity)

    @Query("DELETE FROM games WHERE id = :id")
    suspend fun deleteById(id: Long)
}

@Dao
interface AnalysisHistoryDao {
    @Query("SELECT * FROM analysis_history ORDER BY analyzedAt DESC")
    fun observeAll(): Flow<List<AnalysisHistoryEntity>>

    @Query("SELECT * FROM analysis_history ORDER BY analyzedAt DESC LIMIT 1")
    fun observeLatest(): Flow<AnalysisHistoryEntity?>

    @Query("SELECT * FROM analysis_history WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): AnalysisHistoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: AnalysisHistoryEntity): Long

    @Query("DELETE FROM analysis_history WHERE id = :id")
    suspend fun deleteById(id: Long)
}

@Dao
interface AuthorizedEditorDao {
    @Query("SELECT * FROM authorized_profiles ORDER BY updatedAt DESC")
    fun observeProfiles(): Flow<List<AuthorizedProfileEntity>>

    @Query("SELECT * FROM authorized_profiles WHERE id = :id LIMIT 1")
    suspend fun getProfileById(id: Long): AuthorizedProfileEntity?

    @Query("SELECT COUNT(*) FROM authorized_profiles")
    suspend fun countProfiles(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: AuthorizedProfileEntity): Long

    @Update
    suspend fun updateProfile(profile: AuthorizedProfileEntity)

    @Query("SELECT * FROM value_backups WHERE profileId = :profileId ORDER BY createdAt DESC")
    fun observeBackups(profileId: Long): Flow<List<ValueBackupEntity>>

    @Query("SELECT * FROM value_backups WHERE id = :backupId LIMIT 1")
    suspend fun getBackupById(backupId: Long): ValueBackupEntity?

    @Insert
    suspend fun insertBackup(backup: ValueBackupEntity): Long

    @Query("SELECT * FROM value_change_logs WHERE profileId = :profileId ORDER BY timestamp DESC LIMIT 50")
    fun observeChangeLogs(profileId: Long): Flow<List<ValueChangeLogEntity>>

    @Insert
    suspend fun insertChangeLog(log: ValueChangeLogEntity): Long
}

@Dao
interface AuditLogDao {
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 100")
    fun observeRecent(): Flow<List<AuditLogEntity>>

    @Insert
    suspend fun insert(log: AuditLogEntity): Long

    @Query("DELETE FROM audit_logs")
    suspend fun clearAll()
}
