package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.domain.AppSettings
import com.example.security.CryptoVaultManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "game_hacker_settings")

class SettingsRepository(
    private val context: Context,
    private val cryptoVault: CryptoVaultManager = CryptoVaultManager()
) {
    private object Keys {
        val MAX_APK_SIZE_MB = intPreferencesKey("max_apk_size_mb")
        val MAX_ZIP_ENTRIES = intPreferencesKey("max_zip_entries")
        val DEEP_DEX_SCAN = booleanPreferencesKey("deep_dex_scan")
        val AUTO_BACKUP = booleanPreferencesKey("auto_backup_before_edit")
        val REQUIRE_CONFIRMATION = booleanPreferencesKey("require_confirmation_before_edit")
        val ENCRYPTED_ENDPOINT_NOTE = stringPreferencesKey("encrypted_endpoint_note")
    }

    val settingsFlow: Flow<AppSettings> = context.settingsDataStore.data.map { prefs ->
        AppSettings(
            maxApkSizeMb = prefs[Keys.MAX_APK_SIZE_MB] ?: 250,
            maxZipEntries = prefs[Keys.MAX_ZIP_ENTRIES] ?: 10_000,
            deepDexScanEnabled = prefs[Keys.DEEP_DEX_SCAN] ?: true,
            autoBackupBeforeEdit = prefs[Keys.AUTO_BACKUP] ?: true,
            requireConfirmationBeforeEdit = prefs[Keys.REQUIRE_CONFIRMATION] ?: true
        )
    }

    val vaultNoteFlow: Flow<String> = context.settingsDataStore.data.map { prefs ->
        val stored = prefs[Keys.ENCRYPTED_ENDPOINT_NOTE].orEmpty()
        if (stored.isBlank()) "" else cryptoVault.decrypt(stored)
    }

    suspend fun updateMaxApkSizeMb(sizeMb: Int) {
        context.settingsDataStore.edit { it[Keys.MAX_APK_SIZE_MB] = sizeMb.coerceIn(20, 500) }
    }

    suspend fun updateMaxZipEntries(entries: Int) {
        context.settingsDataStore.edit { it[Keys.MAX_ZIP_ENTRIES] = entries.coerceIn(1000, 50_000) }
    }

    suspend fun setDeepDexScan(enabled: Boolean) {
        context.settingsDataStore.edit { it[Keys.DEEP_DEX_SCAN] = enabled }
    }

    suspend fun setAutoBackup(enabled: Boolean) {
        context.settingsDataStore.edit { it[Keys.AUTO_BACKUP] = enabled }
    }

    suspend fun setRequireConfirmation(enabled: Boolean) {
        context.settingsDataStore.edit { it[Keys.REQUIRE_CONFIRMATION] = enabled }
    }

    suspend fun saveEncryptedEndpointConfig(note: String) {
        val encrypted = cryptoVault.encrypt(note.trim())
        context.settingsDataStore.edit { it[Keys.ENCRYPTED_ENDPOINT_NOTE] = encrypted }
    }

    fun isKeystoreHardwareAvailable(): Boolean = cryptoVault.isKeystoreAvailable()
}
