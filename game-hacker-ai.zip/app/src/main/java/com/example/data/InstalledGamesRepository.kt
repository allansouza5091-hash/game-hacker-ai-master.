package com.example.data

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.os.Build
import com.example.analysis.ApkMetadataExtractor
import com.example.domain.InstalledAppInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class InstalledGamesRepository(private val context: Context) {

    suspend fun loadVisibleInstalledApps(): List<InstalledAppInfo> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val resolveInfos: List<ResolveInfo> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(launcherIntent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(launcherIntent, 0)
        }

        val seenPackages = mutableSetOf<String>()
        val result = mutableListOf<InstalledAppInfo>()

        for (resolve in resolveInfos) {
            val activityInfo = resolve.activityInfo ?: continue
            val pkgName = activityInfo.packageName ?: continue
            if (!seenPackages.add(pkgName)) continue

            val appInfo = activityInfo.applicationInfo
            val pkgInfo = getPackageInfoCompat(pm, pkgName)

            val isGame = isAppGame(appInfo)
            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val appType = when {
                isGame -> "Jogo"
                isSystem -> "Sistema"
                else -> "Aplicativo"
            }

            val label = resolve.loadLabel(pm)?.toString()?.takeIf { it.isNotBlank() }
                ?: appInfo.loadLabel(pm)?.toString().orEmpty()
            val iconBitmap = runCatching {
                ApkMetadataExtractor.drawableToBitmap(resolve.loadIcon(pm))
            }.getOrNull()

            val versionName = pkgInfo?.versionName ?: "N/D"
            val versionCode = if (pkgInfo != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) pkgInfo.longVersionCode
                else @Suppress("DEPRECATION") pkgInfo.versionCode.toLong()
            } else 0L

            result.add(
                InstalledAppInfo(
                    name = label.ifBlank { pkgName },
                    packageName = pkgName,
                    versionName = versionName,
                    versionCode = versionCode,
                    installedAt = pkgInfo?.firstInstallTime,
                    updatedAt = pkgInfo?.lastUpdateTime,
                    isGame = isGame,
                    isSystemApp = isSystem,
                    appTypeLabel = appType,
                    sourceDir = appInfo.publicSourceDir ?: appInfo.sourceDir,
                    iconBitmap = iconBitmap
                )
            )
        }

        result.sortedWith(
            compareByDescending<InstalledAppInfo> { it.isGame }
                .thenBy { it.name.lowercase() }
        )
    }

    private fun isAppGame(appInfo: ApplicationInfo): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && appInfo.category == ApplicationInfo.CATEGORY_GAME) {
            return true
        }
        @Suppress("DEPRECATION")
        return (appInfo.flags and ApplicationInfo.FLAG_IS_GAME) != 0
    }

    private fun getPackageInfoCompat(pm: PackageManager, packageName: String): PackageInfo? {
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(packageName, 0)
            }
        }.getOrNull()
    }
}
