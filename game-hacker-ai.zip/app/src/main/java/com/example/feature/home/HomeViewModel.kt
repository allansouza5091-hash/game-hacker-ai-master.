package com.example.feature.home

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.ai.GameAiEngine
import com.example.core.AppContainer
import com.example.core.Formatters
import com.example.data.AnalysisHistoryRepository
import com.example.data.GameLibraryRepository
import com.example.data.SettingsRepository
import com.example.domain.AppSettings
import com.example.domain.GameRecord
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeUiState(
    val importedGamesCount: Int = 0,
    val lastAnalysisLabel: String = "Nenhuma análise executada",
    val systemStateLabel: String = "Proteção Ativa • Sandbox Isolado",
    val aiEngineLabel: String = "Local Técnico (Firebase AI desativado)",
    val recentGames: List<GameRecord> = emptyList(),
    val isImporting: Boolean = false,
    val importFeedback: String? = null,
    val importError: String? = null
)

class HomeViewModel(
    private val gameLibraryRepository: GameLibraryRepository,
    private val historyRepository: AnalysisHistoryRepository,
    private val settingsRepository: SettingsRepository,
    private val aiEngine: GameAiEngine
) : ViewModel() {

    private val isImporting = MutableStateFlow(false)
    private val importFeedback = MutableStateFlow<String?>(null)
    private val importError = MutableStateFlow<String?>(null)

    val uiState: StateFlow<HomeUiState> = combine(
        gameLibraryRepository.gamesFlow,
        historyRepository.latestHistoryItemFlow,
        isImporting,
        importFeedback,
        importError
    ) { games, latest, importing, feedback, error ->
        val lastLabel = if (latest != null) {
            "${latest.gameName} (${Formatters.formatDateTime(latest.analyzedAt)})"
        } else {
            "Nenhuma análise executada"
        }
        val keystoreOk = settingsRepository.isKeystoreHardwareAvailable()
        HomeUiState(
            importedGamesCount = games.size,
            lastAnalysisLabel = lastLabel,
            systemStateLabel = if (keystoreOk) {
                "Online Local • Keystore + SAF Ativos"
            } else {
                "Online Local • Modo Compatível"
            },
            aiEngineLabel = aiEngine.engineLabel,
            recentGames = games.take(3),
            isImporting = importing,
            importFeedback = feedback,
            importError = error
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = HomeUiState(aiEngineLabel = aiEngine.engineLabel)
    )

    fun importApk(uri: Uri, onImported: (GameRecord) -> Unit = {}) {
        viewModelScope.launch {
            isImporting.value = true
            importFeedback.value = null
            importError.value = null
            val settings: AppSettings = settingsRepository.settingsFlow.first()
            val result = gameLibraryRepository.importApkFromUri(
                uri = uri,
                maxSizeMb = settings.maxApkSizeMb,
                maxEntries = settings.maxZipEntries,
                deepDexScan = settings.deepDexScanEnabled
            )
            isImporting.value = false
            result.fold(
                onSuccess = { (record, outcome) ->
                    val warnSuffix = if (outcome.warnings.isNotEmpty()) {
                        " (${outcome.warnings.size} aviso(s))"
                    } else ""
                    importFeedback.value = "APK validado e salvo: ${record.name} v${record.versionName}$warnSuffix"
                    onImported(record)
                },
                onFailure = { err ->
                    importError.value = err.localizedMessage ?: "Falha ao importar o arquivo APK."
                }
            )
        }
    }

    fun clearMessages() {
        importFeedback.value = null
        importError.value = null
    }

    class Factory(private val container: AppContainer) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return HomeViewModel(
                gameLibraryRepository = container.gameLibraryRepository,
                historyRepository = container.analysisHistoryRepository,
                settingsRepository = container.settingsRepository,
                aiEngine = container.aiEngine
            ) as T
        }
    }
}
