package com.example.feature.analysis

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.AnalysisPipelineEvent
import com.example.core.AppContainer
import com.example.core.GameAnalysisOrchestrator
import com.example.data.AnalysisHistoryRepository
import com.example.data.GameLibraryRepository
import com.example.data.SettingsRepository
import com.example.domain.AnalysisReport
import com.example.domain.AnalysisStep
import com.example.domain.GameRecord
import com.example.domain.InstalledAppInfo
import com.example.domain.UiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AnalysisViewModel(
    private val gameLibraryRepository: GameLibraryRepository,
    private val historyRepository: AnalysisHistoryRepository,
    private val settingsRepository: SettingsRepository,
    private val orchestrator: GameAnalysisOrchestrator
) : ViewModel() {

    val libraryGames: StateFlow<List<GameRecord>> = gameLibraryRepository.gamesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _steps = MutableStateFlow<List<AnalysisStep>>(emptyList())
    val steps: StateFlow<List<AnalysisStep>> = _steps.asStateFlow()

    private val _reportState = MutableStateFlow<UiState<AnalysisReport>>(UiState.Idle)
    val reportState: StateFlow<UiState<AnalysisReport>> = _reportState.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    fun importAndAnalyzeUri(uri: Uri) {
        viewModelScope.launch {
            _reportState.value = UiState.Loading("Importando e validando APK...")
            val settings = settingsRepository.settingsFlow.first()
            val importRes = gameLibraryRepository.importApkFromUri(
                uri = uri,
                maxSizeMb = settings.maxApkSizeMb,
                maxEntries = settings.maxZipEntries,
                deepDexScan = settings.deepDexScanEnabled
            )
            importRes.fold(
                onSuccess = { (record, _) ->
                    analyzeGame(record)
                },
                onFailure = { err ->
                    _reportState.value = UiState.Error(
                        err.localizedMessage ?: "Arquivo APK inválido ou ilegível."
                    )
                }
            )
        }
    }

    fun analyzeGame(game: GameRecord) {
        viewModelScope.launch {
            _reportState.value = UiState.Loading("Executando pipeline de análise...")
            val settings = settingsRepository.settingsFlow.first()
            orchestrator.analyzeGameRecord(game, settings).collect { event ->
                when (event) {
                    is AnalysisPipelineEvent.Progress -> _steps.value = event.steps
                    is AnalysisPipelineEvent.Finished -> _reportState.value = UiState.Success(event.report)
                    is AnalysisPipelineEvent.Failed -> _reportState.value = UiState.Error(event.message)
                }
            }
        }
    }

    fun analyzeInstalledApp(app: InstalledAppInfo) {
        viewModelScope.launch {
            _reportState.value = UiState.Loading("Inspecionando pacote instalado...")
            val settings = settingsRepository.settingsFlow.first()
            orchestrator.analyzeInstalledApp(app, settings).collect { event ->
                when (event) {
                    is AnalysisPipelineEvent.Progress -> _steps.value = event.steps
                    is AnalysisPipelineEvent.Finished -> _reportState.value = UiState.Success(event.report)
                    is AnalysisPipelineEvent.Failed -> _reportState.value = UiState.Error(event.message)
                }
            }
        }
    }

    fun openSavedReport(reportId: Long) {
        viewModelScope.launch {
            _reportState.value = UiState.Loading("Carregando relatório salvo...")
            val report = historyRepository.getFullReport(reportId)
            if (report != null) {
                _steps.value = emptyList()
                _reportState.value = UiState.Success(report)
            } else {
                _reportState.value = UiState.Error("Relatório #$reportId não encontrado no histórico.")
            }
        }
    }

    fun removeFromLibrary(gameId: Long, deleteCachedCopy: Boolean) {
        viewModelScope.launch {
            gameLibraryRepository.removeFromLibrary(gameId, deleteCachedCopy)
            _statusBanner.value = "Registro removido da biblioteca interna (arquivo original preservado)."
        }
    }

    fun clearBanner() {
        _statusBanner.value = null
    }

    class Factory(private val container: AppContainer) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return AnalysisViewModel(
                gameLibraryRepository = container.gameLibraryRepository,
                historyRepository = container.analysisHistoryRepository,
                settingsRepository = container.settingsRepository,
                orchestrator = container.analysisOrchestrator
            ) as T
        }
    }
}
