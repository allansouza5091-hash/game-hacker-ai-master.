package com.example.feature.history

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.History
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.Formatters
import com.example.feature.analysis.AnalysisReportContent
import com.example.feature.components.CyberPanel
import com.example.feature.components.SectionHeader
import com.example.feature.components.StatusPill
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberRed
import com.example.ui.theme.DeepBlack
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.MutedSilver
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonPurpleBright
import com.example.ui.theme.PureWhite

@Composable
fun HistoryScreen(
    viewModel: HistoryViewModel
) {
    val items by viewModel.historyItems.collectAsStateWithLifecycle()
    val selectedReport by viewModel.selectedReport.collectAsStateWithLifecycle()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 920.dp)
                .align(Alignment.TopCenter)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SectionHeader(
                    title = "HISTÓRICO DE ANÁLISES (${items.size})",
                    subtitle = "Toque em qualquer registro para reabrir o relatório técnico completo"
                )
            }

            if (items.isEmpty()) {
                item {
                    CyberPanel(glowColor = NeonPurple) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 18.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.History,
                                contentDescription = "Histórico vazio",
                                tint = NeonPurpleBright,
                                modifier = Modifier.size(44.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Nenhuma análise registrada ainda.",
                                style = MaterialTheme.typography.titleSmall,
                                color = PureWhite
                            )
                            Text(
                                text = "Execute uma análise em 'ANALISAR COM IA' ou 'JOGOS INSTALADOS' para salvar o relatório aqui.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MutedSilver
                            )
                        }
                    }
                }
            } else {
                items(items.size) { idx ->
                    val item = items[idx]
                    CyberPanel(
                        glowColor = ElectricBlue,
                        modifier = Modifier
                            .testTag("history_item_${item.id}")
                            .clickable { viewModel.openReport(item.id) }
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.gameName,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = PureWhite
                                )
                                Text(
                                    text = item.packageName,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = ElectricBlue
                                )
                                Text(
                                    text = Formatters.formatDateTime(item.analyzedAt),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MutedSilver
                                )
                            }
                            IconButton(onClick = { viewModel.deleteReport(item.id) }) {
                                Icon(
                                    imageVector = Icons.Rounded.DeleteOutline,
                                    contentDescription = "Excluir registro",
                                    tint = CyberRed
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatusPill(label = "${item.variablesCount} variáveis", color = CyberGreen)
                            if (item.errorsCount > 0) {
                                StatusPill(label = "${item.errorsCount} avisos", color = CyberAmber)
                            }
                            StatusPill(label = item.resultSummary, color = NeonPurpleBright)
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }

    selectedReport?.let { report ->
        AlertDialog(
            onDismissRequest = viewModel::closeReport,
            title = { Text("Relatório: ${report.gameName}") },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    AnalysisReportContent(report = report)
                }
            },
            confirmButton = {
                TextButton(onClick = viewModel::closeReport) {
                    Text("Fechar")
                }
            }
        )
    }
}
