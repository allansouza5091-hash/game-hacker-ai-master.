package com.example.feature.editor

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.AppContainer
import com.example.data.AuthorizedEditorRepository
import com.example.data.EditorValuesInput
import com.example.data.SettingsRepository
import com.example.domain.AuthorizedGameProfile
import com.example.domain.ValueBackupSnapshot
import com.example.domain.ValueChangeLog
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ValueEditorViewModel(
    private val editorRepository: AuthorizedEditorRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    val profiles: StateFlow<List<AuthorizedGameProfile>> = editorRepository.profilesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedProfileId = MutableStateFlow<Long?>(null)
    val selectedProfileId: StateFlow<Long?> = _selectedProfileId.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val backups: StateFlow<List<ValueBackupSnapshot>> = _selectedProfileId
        .filterNotNull()
        .flatMapLatest { editorRepository.observeBackups(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val changeLogs: StateFlow<List<ValueChangeLog>> = _selectedProfileId
        .filterNotNull()
        .flatMapLatest { editorRepository.observeChangeLogs(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _feedbackMessage = MutableStateFlow<String?>(null)
    val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    init {
        viewModelScope.launch {
            editorRepository.ensureDefaultAuthorizedProfile()
            profiles.collect { list ->
                if (_selectedProfileId.value == null && list.isNotEmpty()) {
                    _selectedProfileId.value = list.first().id
                }
            }
        }
    }

    fun selectProfile(profileId: Long) {
        _selectedProfileId.value = profileId
        clearMessages()
    }

    fun validateFields(
        scoreText: String,
        coinsText: String,
        livesText: String,
        energyText: String,
        xpText: String,
        levelText: String
    ): Result<EditorValuesInput> {
        val score = scoreText.toIntOrNull()
            ?: return Result.failure(IllegalArgumentException("Pontuação inválida: informe um número inteiro."))
        val coins = coinsText.toIntOrNull()
            ?: return Result.failure(IllegalArgumentException("Moedas inválidas: informe um número inteiro."))
        val lives = livesText.toIntOrNull()
            ?: return Result.failure(IllegalArgumentException("Vidas inválidas: informe um número inteiro."))
        val energy = energyText.toIntOrNull()
            ?: return Result.failure(IllegalArgumentException("Energia inválida: informe um número inteiro."))
        val xp = xpText.toIntOrNull()
            ?: return Result.failure(IllegalArgumentException("XP inválido: informe um número inteiro."))
        val level = levelText.toIntOrNull()
            ?: return Result.failure(IllegalArgumentException("Nível inválido: informe um número inteiro."))

        val input = EditorValuesInput(score, coins, lives, energy, xp, level)
        editorRepository.validateInput(input)?.let { err ->
            return Result.failure(IllegalArgumentException(err))
        }
        return Result.success(input)
    }

    fun applyChanges(profileId: Long, input: EditorValuesInput) {
        viewModelScope.launch {
            clearMessages()
            val settings = settingsRepository.settingsFlow.first()
            editorRepository.applyChanges(profileId, input, createAutoBackup = settings.autoBackupBeforeEdit)
                .fold(
                    onSuccess = { updated ->
                        _feedbackMessage.value = "Alterações aplicadas em '${updated.gameName}' com backup automático salvo."
                    },
                    onFailure = { err ->
                        _errorMessage.value = err.localizedMessage ?: "Falha ao aplicar alterações."
                    }
                )
        }
    }

    fun createManualBackup(profileId: Long) {
        viewModelScope.launch {
            clearMessages()
            editorRepository.createManualBackup(profileId, "Backup manual do usuário").fold(
                onSuccess = { _feedbackMessage.value = "Backup de segurança criado com sucesso." },
                onFailure = { _errorMessage.value = it.localizedMessage ?: "Falha ao criar backup." }
            )
        }
    }

    fun restoreBackup(backupId: Long) {
        viewModelScope.launch {
            clearMessages()
            editorRepository.restoreFromBackup(backupId).fold(
                onSuccess = { restored ->
                    _feedbackMessage.value = "Valores de '${restored.gameName}' restaurados do backup #$backupId."
                },
                onFailure = { _errorMessage.value = it.localizedMessage ?: "Falha ao restaurar backup." }
            )
        }
    }

    fun importAuthorizedJson(uri: Uri) {
        viewModelScope.launch {
            clearMessages()
            editorRepository.importAuthorizedJsonProfile(uri).fold(
                onSuccess = { profile ->
                    _selectedProfileId.value = profile.id
                    _feedbackMessage.value = "Perfil autorizado '${profile.gameName}' importado."
                },
                onFailure = { _errorMessage.value = it.localizedMessage ?: "Falha ao importar JSON." }
            )
        }
    }

    fun exportProfileJson(profileId: Long, uri: Uri) {
        viewModelScope.launch {
            clearMessages()
            editorRepository.exportProfileToJsonUri(profileId, uri).fold(
                onSuccess = { _feedbackMessage.value = "Backup JSON exportado com sucesso." },
                onFailure = { _errorMessage.value = it.localizedMessage ?: "Falha ao exportar JSON." }
            )
        }
    }

    fun clearMessages() {
        _feedbackMessage.value = null
        _errorMessage.value = null
    }

    class Factory(private val container: AppContainer) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ValueEditorViewModel(
                editorRepository = container.authorizedEditorRepository,
                settingsRepository = container.settingsRepository
            ) as T
        }
    }
}
