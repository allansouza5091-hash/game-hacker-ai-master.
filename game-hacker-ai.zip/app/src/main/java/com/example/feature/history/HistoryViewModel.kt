package com.example.feature.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.AppContainer
import com.example.data.AnalysisHistoryRepository
import com.example.data.HistorySummaryItem
import com.example.domain.AnalysisReport
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HistoryViewModel(
    private val historyRepository: AnalysisHistoryRepository
) : ViewModel() {

    val historyItems: StateFlow<List<HistorySummaryItem>> = historyRepository.historyItemsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedReport = MutableStateFlow<AnalysisReport?>(null)
    val selectedReport: StateFlow<AnalysisReport?> = _selectedReport.asStateFlow()

    fun openReport(reportId: Long) {
        viewModelScope.launch {
            _selectedReport.value = historyRepository.getFullReport(reportId)
        }
    }

    fun closeReport() {
        _selectedReport.value = null
    }

    fun deleteReport(reportId: Long) {
        viewModelScope.launch {
            historyRepository.deleteReport(reportId)
            if (_selectedReport.value?.id == reportId) {
                _selectedReport.value = null
            }
        }
    }

    class Factory(private val container: AppContainer) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return HistoryViewModel(container.analysisHistoryRepository) as T
        }
    }
}
