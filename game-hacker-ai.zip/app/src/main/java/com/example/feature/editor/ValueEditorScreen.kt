package com.example.feature.editor

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.VerifiedUser
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.core.Formatters
import com.example.data.EditorValuesInput
import com.example.feature.components.CyberPanel
import com.example.feature.components.SectionHeader
import com.example.feature.components.StatusPill
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberOutline
import com.example.ui.theme.CyberRed
import com.example.ui.theme.DeepBlack
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.MutedSilver
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonPurpleBright
import com.example.ui.theme.PureWhite

@Composable
fun ValueEditorScreen(
    viewModel: ValueEditorViewModel
) {
    val profiles by viewModel.profiles.collectAsStateWithLifecycle()
    val selectedProfileId by viewModel.selectedProfileId.collectAsStateWithLifecycle()
    val backups by viewModel.backups.collectAsStateWithLifecycle()
    val changeLogs by viewModel.changeLogs.collectAsStateWithLifecycle()
    val feedbackMessage by viewModel.feedbackMessage.collectAsStateWithLifecycle()
    val errorMessage by viewModel.errorMessage.collectAsStateWithLifecycle()

    val activeProfile = profiles.firstOrNull { it.id == selectedProfileId } ?: profiles.firstOrNull()

    var scoreText by remember(activeProfile?.id) { mutableStateOf(activeProfile?.score?.toString() ?: "500") }
    var coinsText by remember(activeProfile?.id) { mutableStateOf(activeProfile?.coins?.toString() ?: "100") }
    var livesText by remember(activeProfile?.id) { mutableStateOf(activeProfile?.lives?.toString() ?: "3") }
    var energyText by remember(activeProfile?.id) { mutableStateOf(activeProfile?.energy?.toString() ?: "100") }
    var xpText by remember(activeProfile?.id) { mutableStateOf(activeProfile?.xp?.toString() ?: "250") }
    var levelText by remember(activeProfile?.id) { mutableStateOf(activeProfile?.level?.toString() ?: "5") }

    LaunchedEffect(
        activeProfile?.score,
        activeProfile?.coins,
        activeProfile?.lives,
        activeProfile?.energy,
        activeProfile?.xp,
        activeProfile?.level
    ) {
        activeProfile?.let {
            scoreText = it.score.toString()
            coinsText = it.coins.toString()
            livesText = it.lives.toString()
            energyText = it.energy.toString()
            xpText = it.xp.toString()
            levelText = it.level.toString()
        }
    }

    var localValidationError by remember { mutableStateOf<String?>(null) }
    var pendingConfirmedInput by remember { mutableStateOf<EditorValuesInput?>(null) }

    val importJsonLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) viewModel.importAuthorizedJson(uri)
    }

    val exportJsonLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null && activeProfile != null) {
            viewModel.exportProfileJson(activeProfile.id, uri)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 920.dp)
                .align(Alignment.TopCenter)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SectionHeader(
                    title = "EDITOR DE VALORES",
                    subtitle = "Edição validada com backup e restauração para jogos próprios/autorizados"
                )
            }

            item {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = CyberGreen.copy(alpha = 0.10f),
                    border = BorderStroke(1.dp, CyberGreen.copy(alpha = 0.45f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.VerifiedUser,
                            contentDescription = "Apenas projetos autorizados",
                            tint = CyberGreen,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = stringResource(R.string.editor_authorized_only_notice),
                            style = MaterialTheme.typography.bodySmall,
                            color = PureWhite
                        )
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { importJsonLauncher.launch(arrayOf("application/json", "*/*")) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_import_json_profile")
                    ) {
                        Icon(Icons.Rounded.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Importar JSON", style = MaterialTheme.typography.labelMedium)
                    }
                    OutlinedButton(
                        onClick = {
                            val name = (activeProfile?.gameName ?: "perfil").replace(" ", "_").lowercase()
                            exportJsonLauncher.launch("${name}_backup.json")
                        },
                        enabled = activeProfile != null,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_export_json_profile")
                    ) {
                        Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Exportar Backup", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }

            if (profiles.isNotEmpty()) {
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(profiles, key = { it.id }) { profile ->
                            FilterChip(
                                selected = profile.id == activeProfile?.id,
                                onClick = { viewModel.selectProfile(profile.id) },
                                label = { Text(profile.gameName) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NeonPurple.copy(alpha = 0.28f),
                                    selectedLabelColor = PureWhite
                                )
                            )
                        }
                    }
                }
            }

            val displayedError = localValidationError ?: errorMessage
            if (displayedError != null) {
                item {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = CyberRed.copy(alpha = 0.14f),
                        border = BorderStroke(1.dp, CyberRed.copy(alpha = 0.6f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.ErrorOutline, contentDescription = "Erro", tint = CyberRed)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(displayedError, style = MaterialTheme.typography.bodySmall, color = PureWhite)
                        }
                    }
                }
            }

            if (feedbackMessage != null) {
                item {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = CyberGreen.copy(alpha = 0.14f),
                        border = BorderStroke(1.dp, CyberGreen.copy(alpha = 0.6f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.CheckCircle, contentDescription = "Sucesso", tint = CyberGreen)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(feedbackMessage.orEmpty(), style = MaterialTheme.typography.bodySmall, color = PureWhite)
                        }
                    }
                }
            }

            activeProfile?.let { profile ->
                item {
                    CyberPanel(glowColor = ElectricBlue, elevated = true) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "JOGO: ${profile.gameName}",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = PureWhite
                                )
                                Text(
                                    text = "${profile.packageName} • ${profile.authorizationSource}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ElectricBlue
                                )
                            }
                            StatusPill(label = "AUTORIZADO", color = CyberGreen)
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        EditableMetricField(
                            title = "PONTUAÇÃO",
                            currentValue = profile.score.toString(),
                            valueText = scoreText,
                            onValueChange = { scoreText = it; localValidationError = null },
                            tag = "input_score"
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        EditableMetricField(
                            title = "MOEDAS",
                            currentValue = profile.coins.toString(),
                            valueText = coinsText,
                            onValueChange = { coinsText = it; localValidationError = null },
                            tag = "input_coins"
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        EditableMetricField(
                            title = "VIDAS",
                            currentValue = profile.lives.toString(),
                            valueText = livesText,
                            onValueChange = { livesText = it; localValidationError = null },
                            tag = "input_lives"
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            EditableCompactField(
                                title = "ENERGIA",
                                currentValue = profile.energy.toString(),
                                valueText = energyText,
                                onValueChange = { energyText = it; localValidationError = null },
                                tag = "input_energy",
                                modifier = Modifier.weight(1f)
                            )
                            EditableCompactField(
                                title = "XP",
                                currentValue = profile.xp.toString(),
                                valueText = xpText,
                                onValueChange = { xpText = it; localValidationError = null },
                                tag = "input_xp",
                                modifier = Modifier.weight(1f)
                            )
                            EditableCompactField(
                                title = "NÍVEL",
                                currentValue = profile.level.toString(),
                                valueText = levelText,
                                onValueChange = { levelText = it; localValidationError = null },
                                tag = "input_level",
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = {
                                    localValidationError = null
                                    val validated = viewModel.validateFields(
                                        scoreText, coinsText, livesText, energyText, xpText, levelText
                                    )
                                    validated.fold(
                                        onSuccess = { input -> pendingConfirmedInput = input },
                                        onFailure = { err -> localValidationError = err.localizedMessage }
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = NeonPurpleBright,
                                    contentColor = DeepBlack
                                ),
                                modifier = Modifier
                                    .weight(1.4f)
                                    .testTag("btn_apply_changes")
                            ) {
                                Icon(Icons.Rounded.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = stringResource(R.string.editor_apply_changes),
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }

                            OutlinedButton(
                                onClick = { viewModel.createManualBackup(profile.id) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_manual_backup")
                            ) {
                                Icon(Icons.Rounded.Backup, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Backup", style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }
            }

            item {
                SectionHeader(
                    title = "BACKUPS & RESTAURAÇÃO (${backups.size})",
                    subtitle = "Snapshots salvos automaticamente antes de cada alteração"
                )
            }

            items(backups.size) { idx ->
                val snap = backups[idx]
                CyberPanel(glowColor = CyberGreen) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = snap.reason,
                                style = MaterialTheme.typography.titleSmall,
                                color = PureWhite
                            )
                            Text(
                                text = "Pontuação: ${snap.score} • Moedas: ${snap.coins} • Vidas: ${snap.lives}",
                                style = MaterialTheme.typography.labelMedium,
                                color = ElectricBlue
                            )
                            Text(
                                text = Formatters.formatDateTime(snap.createdAt),
                                style = MaterialTheme.typography.labelSmall,
                                color = MutedSilver
                            )
                        }
                        OutlinedButton(
                            onClick = { viewModel.restoreBackup(snap.id) },
                            modifier = Modifier.testTag("btn_restore_backup_${snap.id}")
                        ) {
                            Icon(Icons.Rounded.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Restaurar", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }

            if (changeLogs.isNotEmpty()) {
                item {
                    SectionHeader(
                        title = "REGISTRO DE ALTERAÇÕES",
                        subtitle = "Auditoria de modificações no perfil autorizado"
                    )
                }
                items(changeLogs.size) { idx ->
                    val log = changeLogs[idx]
                    CyberPanel(glowColor = CyberOutline) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${log.fieldChanged}: ${log.oldValue} → ${log.newValue}",
                                style = MaterialTheme.typography.bodySmall,
                                color = PureWhite,
                                modifier = Modifier.weight(1f)
                            )
                            StatusPill(
                                label = log.status,
                                color = if (log.status == "RESTORED") ElectricBlue else CyberGreen
                            )
                        }
                        Text(
                            text = Formatters.formatDateTime(log.timestamp),
                            style = MaterialTheme.typography.labelSmall,
                            color = MutedSilver
                        )
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }

    if (pendingConfirmedInput != null && activeProfile != null) {
        val pending = pendingConfirmedInput!!
        AlertDialog(
            onDismissRequest = { pendingConfirmedInput = null },
            title = { Text("Confirmar alterações?") },
            text = {
                Text(
                    "Aplicar novos valores em '${activeProfile.gameName}'?\n\n" +
                        "Pontuação: ${activeProfile.score} → ${pending.score}\n" +
                        "Moedas: ${activeProfile.coins} → ${pending.coins}\n" +
                        "Vidas: ${activeProfile.lives} → ${pending.lives}\n" +
                        "Energia: ${activeProfile.energy} → ${pending.energy}\n" +
                        "XP: ${activeProfile.xp} → ${pending.xp} | Nível: ${activeProfile.level} → ${pending.level}"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.applyChanges(activeProfile.id, pending)
                        pendingConfirmedInput = null
                    },
                    modifier = Modifier.testTag("btn_confirm_apply_dialog")
                ) {
                    Text("Confirmar")
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingConfirmedInput = null }) {
                    Text("Cancelar")
                }
            }
        )
    }
}

@Composable
private fun EditableMetricField(
    title: String,
    currentValue: String,
    valueText: String,
    onValueChange: (String) -> Unit,
    tag: String
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                color = ElectricBlue,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Valor atual: $currentValue",
                style = MaterialTheme.typography.labelMedium,
                color = MutedSilver
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
            value = valueText,
            onValueChange = onValueChange,
            label = { Text("Novo valor ($title)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonPurpleBright,
                unfocusedBorderColor = CyberOutline,
                focusedContainerColor = CyberCard,
                unfocusedContainerColor = CyberCard,
                focusedTextColor = PureWhite,
                unfocusedTextColor = PureWhite
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag(tag)
        )
    }
}

@Composable
private fun EditableCompactField(
    title: String,
    currentValue: String,
    valueText: String,
    onValueChange: (String) -> Unit,
    tag: String,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Text(text = "$title ($currentValue)", style = MaterialTheme.typography.labelSmall, color = MutedSilver)
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
            value = valueText,
            onValueChange = onValueChange,
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = ElectricBlue,
                unfocusedBorderColor = CyberOutline,
                focusedContainerColor = CyberCard,
                unfocusedContainerColor = CyberCard,
                focusedTextColor = PureWhite,
                unfocusedTextColor = PureWhite
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag(tag)
        )
    }
}
