package com.example.feature.settings

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.core.Formatters
import com.example.feature.components.AiRequirementNoticeBanner
import com.example.feature.components.CyberPanel
import com.example.feature.components.SectionHeader
import com.example.feature.components.StatusPill
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberOutline
import com.example.ui.theme.DeepBlack
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.MutedSilver
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonPurpleBright
import com.example.ui.theme.PureWhite

@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val vaultNote by viewModel.vaultNote.collectAsStateWithLifecycle()
    val auditLogs by viewModel.auditLogs.collectAsStateWithLifecycle()
    val feedback by viewModel.feedback.collectAsStateWithLifecycle()

    var configText by remember { mutableStateOf(vaultNote) }
    LaunchedEffect(vaultNote) {
        if (configText.isEmpty() && vaultNote.isNotEmpty()) {
            configText = vaultNote
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 920.dp)
                .align(Alignment.TopCenter)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SectionHeader(
                    title = "CONFIGURAÇÕES & SEGURANÇA",
                    subtitle = "Limites de processamento APK, cofre Keystore e logs técnicos"
                )
            }

            item {
                AiRequirementNoticeBanner(text = stringResource(R.string.ai_notice_firebase_required))
            }

            if (feedback != null) {
                item {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = CyberGreen.copy(alpha = 0.14f),
                        border = BorderStroke(1.dp, CyberGreen.copy(alpha = 0.55f))
                    ) {
                        Text(
                            text = feedback.orEmpty(),
                            style = MaterialTheme.typography.bodySmall,
                            color = PureWhite,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp)
                        )
                    }
                }
            }

            item {
                CyberPanel(glowColor = ElectricBlue) {
                    Text("STATUS DO MECANISMO DE IA", style = MaterialTheme.typography.labelLarge, color = ElectricBlue)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(viewModel.aiEngineLabel, style = MaterialTheme.typography.bodyMedium, color = PureWhite)
                        StatusPill(
                            label = if (viewModel.isKeystoreAvailable) "KEYSTORE OK" else "FALLBACK",
                            color = CyberGreen
                        )
                    }
                }
            }

            item {
                CyberPanel(glowColor = NeonPurple) {
                    Text("LIMITES DE SEGURANÇA (APK)", style = MaterialTheme.typography.labelLarge, color = NeonPurpleBright)
                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Tamanho máximo do APK: ${settings.maxApkSizeMb} MB",
                        style = MaterialTheme.typography.bodyMedium,
                        color = PureWhite
                    )
                    Slider(
                        value = settings.maxApkSizeMb.toFloat(),
                        onValueChange = { viewModel.updateMaxApkSizeMb(it.toInt()) },
                        valueRange = 25f..500f,
                        modifier = Modifier.testTag("slider_max_apk_mb")
                    )

                    Text(
                        text = "Limite de entradas ZIP (proteção ZIP bomb): ${settings.maxZipEntries}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = PureWhite
                    )
                    Slider(
                        value = settings.maxZipEntries.toFloat(),
                        onValueChange = { viewModel.updateMaxZipEntries(it.toInt()) },
                        valueRange = 1000f..30000f,
                        modifier = Modifier.testTag("slider_max_zip_entries")
                    )

                    SettingToggleRow(
                        title = "Varredura profunda em classes*.dex",
                        subtitle = "Examina tokens ASCII/UTF-8 em bytecode para detectar variáveis prováveis",
                        checked = settings.deepDexScanEnabled,
                        onCheckedChange = viewModel::setDeepDexScan,
                        tag = "switch_deep_dex"
                    )
                    SettingToggleRow(
                        title = "Backup automático antes de editar",
                        subtitle = "Cria snapshot no Room antes de aplicar qualquer alteração autorizada",
                        checked = settings.autoBackupBeforeEdit,
                        onCheckedChange = viewModel::setAutoBackup,
                        tag = "switch_auto_backup"
                    )
                }
            }

            item {
                CyberPanel(glowColor = ElectricBlue) {
                    Text(
                        text = "COFRE DE CONFIGURAÇÃO (ANDROID KEYSTORE)",
                        style = MaterialTheme.typography.labelLarge,
                        color = ElectricBlue
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Armazena localmente notas ou endpoint oficial autorizado criptografado com AES-256-GCM. Nenhuma chave secreta é embutida no APK.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MutedSilver
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = configText,
                        onValueChange = { configText = it; viewModel.clearFeedback() },
                        label = { Text("Endpoint / Nota técnica protegida") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricBlue,
                            unfocusedBorderColor = CyberOutline,
                            focusedContainerColor = CyberCard,
                            unfocusedContainerColor = CyberCard,
                            focusedTextColor = PureWhite,
                            unfocusedTextColor = PureWhite
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_vault_config")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = { viewModel.saveEncryptedConfigNote(configText) },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue, contentColor = DeepBlack),
                        modifier = Modifier.testTag("btn_save_vault")
                    ) {
                        Text("Salvar no Cofre Keystore", style = MaterialTheme.typography.labelLarge)
                    }
                }
            }

            item {
                SectionHeader(
                    title = "LOGS TÉCNICOS (${auditLogs.size})",
                    subtitle = "Auditoria de importações, validações, análises e backups",
                    trailing = {
                        OutlinedButton(onClick = viewModel::clearLogs) {
                            Text("Limpar", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                )
            }

            if (auditLogs.isEmpty()) {
                item {
                    CyberPanel(glowColor = CyberOutline) {
                        Text("Nenhum evento técnico registrado nesta sessão.", color = MutedSilver)
                    }
                }
            } else {
                items(auditLogs.size) { idx ->
                    val log = auditLogs[idx]
                    CyberPanel(glowColor = CyberOutline) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            StatusPill(label = log.category, color = ElectricBlue)
                            Text(
                                text = Formatters.formatDateTime(log.timestamp),
                                style = MaterialTheme.typography.labelSmall,
                                color = MutedSilver
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(log.message, style = MaterialTheme.typography.bodySmall, color = PureWhite)
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}

@Composable
private fun SettingToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    tag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = PureWhite)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MutedSilver)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(tag)
        )
    }
}
