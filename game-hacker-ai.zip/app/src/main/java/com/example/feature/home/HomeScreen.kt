package com.example.feature.home

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddCircleOutline
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.core.Formatters
import com.example.feature.components.AppIconThumbnail
import com.example.feature.components.CyberPanel
import com.example.feature.components.PulsingStatusDot
import com.example.feature.components.SectionHeader
import com.example.feature.components.StatusPill
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberOutline
import com.example.ui.theme.CyberRed
import com.example.ui.theme.DeepBlack
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.MutedSilver
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonPurpleBright
import com.example.ui.theme.PureWhite

data class HomeActionTile(
    val number: String,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val accent: Color,
    val testTag: String,
    val onClick: () -> Unit
)

@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onOpenInstalled: () -> Unit,
    onOpenAnalysis: () -> Unit,
    onOpenEditor: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenSettings: () -> Unit,
    onApkImportedGoToAnalysis: () -> Unit
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    val apkPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            viewModel.importApk(uri) {
                onApkImportedGoToAnalysis()
            }
        }
    }

    val actions = listOf(
        HomeActionTile(
            number = "01",
            title = stringResource(R.string.action_add_apk),
            subtitle = "Seletor SAF oficial & validação",
            icon = Icons.Rounded.AddCircleOutline,
            accent = ElectricBlue,
            testTag = "btn_add_apk",
            onClick = {
                viewModel.clearMessages()
                apkPickerLauncher.launch(
                    arrayOf("application/vnd.android.package-archive", "application/octet-stream", "*/*")
                )
            }
        ),
        HomeActionTile(
            number = "02",
            title = stringResource(R.string.action_installed_games),
            subtitle = "Inspecionar pacotes do dispositivo",
            icon = Icons.Rounded.Apps,
            accent = NeonPurpleBright,
            testTag = "btn_installed_games",
            onClick = onOpenInstalled
        ),
        HomeActionTile(
            number = "03",
            title = stringResource(R.string.action_analyze_ai),
            subtitle = "GAME AI ENGINE & biblioteca",
            icon = Icons.Rounded.AutoAwesome,
            accent = ElectricBlue,
            testTag = "btn_analyze_ai",
            onClick = onOpenAnalysis
        ),
        HomeActionTile(
            number = "04",
            title = stringResource(R.string.action_value_editor),
            subtitle = "Jogos próprios & autorizados",
            icon = Icons.Rounded.Tune,
            accent = CyberGreen,
            testTag = "btn_value_editor",
            onClick = onOpenEditor
        ),
        HomeActionTile(
            number = "05",
            title = stringResource(R.string.action_history),
            subtitle = "Relatórios técnicos salvos",
            icon = Icons.Rounded.History,
            accent = NeonPurpleBright,
            testTag = "btn_history",
            onClick = onOpenHistory
        ),
        HomeActionTile(
            number = "06",
            title = stringResource(R.string.action_settings),
            subtitle = "Limites, cofre Keystore & logs",
            icon = Icons.Rounded.Settings,
            accent = ElectricBlue,
            testTag = "btn_settings",
            onClick = onOpenSettings
        )
    )

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
    ) {
        val columns = if (maxWidth >= 680.dp) 3 else 2

        LazyColumn(
            modifier = Modifier
                .widthIn(max = 920.dp)
                .align(Alignment.TopCenter)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                HeroHeaderBanner(
                    importedCount = state.importedGamesCount,
                    lastAnalysis = state.lastAnalysisLabel,
                    systemState = state.systemStateLabel,
                    aiEngineState = state.aiEngineLabel
                )
            }

            item {
                AnimatedVisibility(visible = state.isImporting) {
                    CyberPanel(glowColor = ElectricBlue) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                color = ElectricBlue,
                                strokeWidth = 2.5.dp
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "Validando assinatura PK, manifesto e SHA-256 do APK...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = PureWhite
                            )
                        }
                    }
                }
            }

            if (state.importFeedback != null) {
                item {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = CyberGreen.copy(alpha = 0.14f),
                        border = BorderStroke(1.dp, CyberGreen.copy(alpha = 0.6f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.CheckCircle, contentDescription = "Sucesso", tint = CyberGreen)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = state.importFeedback.orEmpty(),
                                style = MaterialTheme.typography.bodySmall,
                                color = PureWhite,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            if (state.importError != null) {
                item {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = CyberRed.copy(alpha = 0.14f),
                        border = BorderStroke(1.dp, CyberRed.copy(alpha = 0.6f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.ErrorOutline, contentDescription = "Erro", tint = CyberRed)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = state.importError.orEmpty(),
                                style = MaterialTheme.typography.bodySmall,
                                color = PureWhite,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            item {
                SectionHeader(
                    title = "PAINEL PRINCIPAL",
                    subtitle = "Módulos operacionais de inspeção, análise e edição autorizada"
                )
            }

            val chunkedRows = actions.chunked(columns)
            items(chunkedRows.size) { rowIndex ->
                val rowItems = chunkedRows[rowIndex]
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    rowItems.forEach { tile ->
                        ActionTileCard(
                            tile = tile,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    repeat(columns - rowItems.size) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }

            if (state.recentGames.isNotEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(4.dp))
                    SectionHeader(
                        title = "BIBLIOTECA RECENTE",
                        subtitle = "APKs importados armazenados localmente no Room"
                    )
                }
                items(state.recentGames.size) { idx ->
                    val game = state.recentGames[idx]
                    CyberPanel(
                        glowColor = ElectricBlue,
                        modifier = Modifier
                            .testTag("recent_game_card_${game.id}")
                            .clickable { onOpenAnalysis() }
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AppIconThumbnail(
                                iconPath = game.iconPath,
                                contentDescription = "Ícone de ${game.name}"
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = game.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = PureWhite,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${game.packageName} • v${game.versionName}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MutedSilver,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = Formatters.formatFileSize(game.sizeBytes),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ElectricBlue
                                )
                            }
                            StatusPill(
                                label = game.analysisStatus.label,
                                color = if (game.analysisStatus.name == "COMPLETED") CyberGreen else NeonPurpleBright
                            )
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }
}

@Composable
private fun HeroHeaderBanner(
    importedCount: Int,
    lastAnalysis: String,
    systemState: String,
    aiEngineState: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = CyberCard),
        border = BorderStroke(
            width = 1.2.dp,
            brush = Brush.linearGradient(listOf(NeonPurpleBright, ElectricBlue))
        )
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Image(
                painter = painterResource(id = R.drawable.img_ai_core_banner),
                contentDescription = "Banner neural futurista",
                contentScale = ContentScale.Crop,
                alpha = 0.42f,
                modifier = Modifier
                    .matchParentSize()
                    .clip(RoundedCornerShape(22.dp))
            )
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                DeepBlack.copy(alpha = 0.35f),
                                DeepBlack.copy(alpha = 0.88f)
                            )
                        )
                    )
            )

            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    StatusPill(label = "TELEMETRIA ATIVA", color = ElectricBlue)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PulsingStatusDot(color = CyberGreen)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ARM64 READY",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyberGreen
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = stringResource(R.string.brand_header),
                    style = MaterialTheme.typography.headlineMedium,
                    color = PureWhite,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = stringResource(R.string.brand_subtitle),
                    style = MaterialTheme.typography.labelSmall,
                    color = ElectricBlue
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    TelemetryMiniCell(
                        label = "JOGOS IMPORTADOS",
                        value = importedCount.toString(),
                        accent = ElectricBlue,
                        modifier = Modifier.weight(1f)
                    )
                    TelemetryMiniCell(
                        label = "ÚLTIMA ANÁLISE",
                        value = lastAnalysis,
                        accent = NeonPurpleBright,
                        modifier = Modifier.weight(1.4f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    TelemetryMiniCell(
                        label = "ESTADO DO SISTEMA",
                        value = systemState,
                        accent = CyberGreen,
                        modifier = Modifier.weight(1f)
                    )
                    TelemetryMiniCell(
                        label = "MECANISMO DE IA",
                        value = aiEngineState,
                        accent = NeonPurpleBright,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun TelemetryMiniCell(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = DeepBlack.copy(alpha = 0.72f),
        border = BorderStroke(1.dp, CyberOutline.copy(alpha = 0.85f))
    ) {
        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = accent,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.bodySmall,
                color = PureWhite,
                fontWeight = FontWeight.SemiBold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ActionTileCard(
    tile: HomeActionTile,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .minimumInteractiveComponentSize()
            .testTag(tile.testTag)
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = tile.onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = CyberCard),
        border = BorderStroke(
            width = 1.dp,
            brush = Brush.linearGradient(
                listOf(tile.accent.copy(alpha = 0.65f), CyberOutline)
            )
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(tile.accent.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = tile.icon,
                        contentDescription = tile.title,
                        tint = tile.accent,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Text(
                    text = tile.number,
                    style = MaterialTheme.typography.labelMedium,
                    color = tile.accent.copy(alpha = 0.85f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = tile.title,
                style = MaterialTheme.typography.labelLarge,
                color = PureWhite,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = tile.subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MutedSilver,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
