package com.example.feature.installed

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.Formatters
import com.example.domain.InstalledAppInfo
import com.example.domain.UiState
import com.example.feature.components.AppIconThumbnail
import com.example.feature.components.CyberPanel
import com.example.feature.components.SectionHeader
import com.example.feature.components.StatusPill
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberOutline
import com.example.ui.theme.DeepBlack
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.MutedSilver
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonPurpleBright
import com.example.ui.theme.PureWhite

@Composable
fun InstalledGamesScreen(
    viewModel: InstalledGamesViewModel,
    onInspectApp: (InstalledAppInfo) -> Unit
) {
    val appsState by viewModel.appsState.collectAsStateWithLifecycle()
    val query by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedFilter by viewModel.filter.collectAsStateWithLifecycle()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 920.dp)
                .align(Alignment.TopCenter)
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            SectionHeader(
                title = "JOGOS INSTALADOS",
                subtitle = "Consulta em conformidade com a visibilidade de pacotes do Android",
                trailing = {
                    IconButton(
                        onClick = { viewModel.refresh() },
                        modifier = Modifier.testTag("btn_refresh_installed")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = "Atualizar lista de pacotes",
                            tint = ElectricBlue
                        )
                    }
                }
            )

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = ElectricBlue.copy(alpha = 0.08f),
                border = BorderStroke(1.dp, ElectricBlue.copy(alpha = 0.35f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Security,
                        contentDescription = "Visibilidade Android",
                        tint = ElectricBlue,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Exibe somente pacotes com launcher visível via <queries>. Dados privados de outros apps permanecem protegidos pelo sandbox Android.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MutedSilver
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = query,
                onValueChange = viewModel::updateQuery,
                placeholder = { Text("Buscar por nome ou pacote...") },
                leadingIcon = {
                    Icon(Icons.Rounded.Search, contentDescription = "Buscar", tint = ElectricBlue)
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = CyberOutline,
                    focusedContainerColor = CyberCard,
                    unfocusedContainerColor = CyberCard,
                    focusedTextColor = PureWhite,
                    unfocusedTextColor = PureWhite
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_search_installed")
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                InstalledFilter.entries.forEach { filter ->
                    FilterChip(
                        selected = selectedFilter == filter,
                        onClick = { viewModel.updateFilter(filter) },
                        label = { Text(filter.label, style = MaterialTheme.typography.labelMedium) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NeonPurple.copy(alpha = 0.28f),
                            selectedLabelColor = PureWhite
                        ),
                        modifier = Modifier.testTag("filter_${filter.name.lowercase()}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            when (val state = appsState) {
                is UiState.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = ElectricBlue)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(state.message, color = MutedSilver)
                        }
                    }
                }
                is UiState.Error -> {
                    CyberPanel(glowColor = MaterialTheme.colorScheme.error) {
                        Text(state.message, color = PureWhite)
                    }
                }
                is UiState.Success -> {
                    val filtered = remember(state.data, query, selectedFilter) {
                        state.data.filter { app ->
                            val matchesFilter = when (selectedFilter) {
                                InstalledFilter.ALL -> true
                                InstalledFilter.GAMES_ONLY -> app.isGame
                                InstalledFilter.USER_APPS -> !app.isSystemApp
                            }
                            val q = query.trim().lowercase()
                            val matchesQuery = q.isEmpty() ||
                                app.name.lowercase().contains(q) ||
                                app.packageName.lowercase().contains(q)
                            matchesFilter && matchesQuery
                        }
                    }

                    if (filtered.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Rounded.SportsEsports,
                                    contentDescription = "Nenhum aplicativo encontrado",
                                    tint = NeonPurpleBright,
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Nenhum aplicativo encontrado para este filtro.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MutedSilver
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(bottom = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(filtered, key = { it.packageName }) { app ->
                                InstalledAppCard(app = app, onInspect = { onInspectApp(app) })
                            }
                        }
                    }
                }
                UiState.Idle -> Unit
            }
        }
    }
}

@Composable
private fun InstalledAppCard(
    app: InstalledAppInfo,
    onInspect: () -> Unit
) {
    CyberPanel(glowColor = if (app.isGame) CyberGreen else NeonPurple) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AppIconThumbnail(
                bitmap = app.iconBitmap,
                contentDescription = "Ícone de ${app.name}"
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = app.name,
                        style = MaterialTheme.typography.titleMedium,
                        color = PureWhite,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    StatusPill(
                        label = app.appTypeLabel,
                        color = when {
                            app.isGame -> CyberGreen
                            app.isSystemApp -> MutedSilver
                            else -> ElectricBlue
                        }
                    )
                }
                Text(
                    text = app.packageName,
                    style = MaterialTheme.typography.labelMedium,
                    color = ElectricBlue,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "Versão: ${app.versionName} (${app.versionCode}) • Instalado: ${Formatters.formatDateTime(app.installedAt)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MutedSilver
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            Button(
                onClick = onInspect,
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonPurple.copy(alpha = 0.25f),
                    contentColor = PureWhite
                ),
                border = BorderStroke(1.dp, NeonPurpleBright.copy(alpha = 0.6f)),
                modifier = Modifier.testTag("btn_inspect_${app.packageName}")
            ) {
                Text("Analisar Estrutura", style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}
