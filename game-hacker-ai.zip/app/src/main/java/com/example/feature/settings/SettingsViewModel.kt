package com.example.feature.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.AppContainer
import com.example.data.SettingsRepository
import com.example.domain.AppSettings
import com.example.domain.AuditLogEntry
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val settingsRepository: SettingsRepository,
    private val container: AppContainer
) : ViewModel() {

    val settings: StateFlow<AppSettings> = settingsRepository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    val vaultNote: StateFlow<String> = settingsRepository.vaultNoteFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

    val auditLogs: StateFlow<List<AuditLogEntry>> = container.auditLogsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _feedback = MutableStateFlow<String?>(null)
    val feedback: StateFlow<String?> = _feedback.asStateFlow()

    val isKeystoreAvailable: Boolean = settingsRepository.isKeystoreHardwareAvailable()
    val aiEngineLabel: String = container.aiEngine.engineLabel

    fun updateMaxApkSizeMb(sizeMb: Int) {
        viewModelScope.launch { settingsRepository.updateMaxApkSizeMb(sizeMb) }
    }

    fun updateMaxZipEntries(entries: Int) {
        viewModelScope.launch { settingsRepository.updateMaxZipEntries(entries) }
    }

    fun setDeepDexScan(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.setDeepDexScan(enabled) }
    }

    fun setAutoBackup(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.setAutoBackup(enabled) }
    }

    fun setRequireConfirmation(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.setRequireConfirmation(enabled) }
    }

    fun saveEncryptedConfigNote(note: String) {
        viewModelScope.launch {
            settingsRepository.saveEncryptedEndpointConfig(note)
            _feedback.value = "Configuração protegida via Android Keystore / cofre criptografado."
        }
    }

    fun clearLogs() {
        viewModelScope.launch {
            container.clearAuditLogs()
            _feedback.value = "Logs técnicos reiniciados."
        }
    }

    fun clearFeedback() {
        _feedback.value = null
    }

    class Factory(private val container: AppContainer) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SettingsViewModel(container.settingsRepository, container) as T
        }
    }
}
