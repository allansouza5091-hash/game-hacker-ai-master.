package com.example.feature.analysis

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.Formatters
import com.example.domain.AnalysisReport
import com.example.domain.DetectionStatus
import com.example.domain.DetectedVariable
import com.example.domain.OnlineLimitation
import com.example.feature.components.AiRequirementNoticeBanner
import com.example.feature.components.CyberPanel
import com.example.feature.components.SectionHeader
import com.example.feature.components.StatusPill
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberOutline
import com.example.ui.theme.CyberRed
import com.example.ui.theme.DeepBlack
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.MutedSilver
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonPurpleBright
import com.example.ui.theme.PureWhite

@Composable
fun AnalysisReportContent(report: AnalysisReport) {
    var showRawText by remember(report.id) { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        AiRequirementNoticeBanner(text = report.aiInterpretation.noticeBanner)

        CyberPanel(glowColor = ElectricBlue, elevated = true) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = report.gameName,
                        style = MaterialTheme.typography.headlineSmall,
                        color = PureWhite
                    )
                    Text(
                        text = "${report.packageName} • v${report.metadata.versionName}",
                        style = MaterialTheme.typography.labelMedium,
                        color = ElectricBlue
                    )
                }
                StatusPill(
                    label = "${report.variables.size} referências",
                    color = NeonPurpleBright
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Tamanho: ${Formatters.formatFileSize(report.metadata.sizeBytes)} • Entradas ZIP: ${report.metadata.entryCount} • DEX: ${report.metadata.dexFiles.size}",
                style = MaterialTheme.typography.bodySmall,
                color = MutedSilver
            )
            Text(
                text = "ABIs: ${report.metadata.nativeAbis.ifEmpty { listOf("Dalvik/ART puro") }.joinToString()} • SHA-256: ${report.metadata.sha256.take(18)}...",
                style = MaterialTheme.typography.labelSmall,
                color = MutedSilver
            )
        }

        CyberPanel(glowColor = NeonPurple) {
            Text(
                text = "INTERPRETAÇÃO — GAME AI ENGINE",
                style = MaterialTheme.typography.labelLarge,
                color = NeonPurpleBright
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = report.aiInterpretation.summary,
                style = MaterialTheme.typography.bodyMedium,
                color = PureWhite
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = report.aiInterpretation.architectureAssessment,
                style = MaterialTheme.typography.bodySmall,
                color = MutedSilver
            )
            Spacer(modifier = Modifier.height(8.dp))
            report.aiInterpretation.recommendations.forEach { rec ->
                Text(
                    text = "• $rec",
                    style = MaterialTheme.typography.bodySmall,
                    color = ElectricBlue
                )
            }
        }

        SectionHeader(
            title = "DETECÇÃO DE VARIÁVEIS",
            subtitle = "Diferenciação rigorosa entre palavras em UI, símbolos DEX e valores JSON confirmados"
        )

        if (report.variables.isEmpty()) {
            CyberPanel(glowColor = CyberOutline) {
                Text(
                    text = "Nenhuma referência de pontuação, moedas, vidas, energia ou XP foi encontrada nos arquivos acessíveis deste pacote.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedSilver
                )
            }
        } else {
            report.variables.forEach { variable ->
                DetectedVariableCard(variable)
            }
        }

        SectionHeader(
            title = "LIMITAÇÕES & JOGOS ONLINE",
            subtitle = "Validação de dependências de servidor, faturamento e integridade"
        )

        report.onlineLimitations.forEach { limitation ->
            OnlineLimitationCard(limitation)
        }

        if (report.errorsFound.isNotEmpty()) {
            CyberPanel(glowColor = CyberAmber) {
                Text(
                    text = "AVISOS E LIMITAÇÕES DE LEITURA",
                    style = MaterialTheme.typography.labelLarge,
                    color = CyberAmber
                )
                Spacer(modifier = Modifier.height(6.dp))
                report.errorsFound.forEach { err ->
                    Text(
                        text = "• $err",
                        style = MaterialTheme.typography.bodySmall,
                        color = PureWhite
                    )
                }
            }
        }

        CyberPanel(glowColor = CyberOutline) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "RELATÓRIO TÉCNICO COMPLETO",
                    style = MaterialTheme.typography.labelLarge,
                    color = PureWhite
                )
                TextButton(onClick = { showRawText = !showRawText }) {
                    Text(if (showRawText) "Ocultar" else "Expandir")
                }
            }
            if (showRawText) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = DeepBlack,
                    border = BorderStroke(1.dp, CyberOutline)
                ) {
                    Text(
                        text = report.fullTechnicalReportText,
                        style = MaterialTheme.typography.labelSmall,
                        color = MutedSilver,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun DetectedVariableCard(variable: DetectedVariable) {
    val statusColor = when (variable.status) {
        DetectionStatus.CONFIRMADO -> CyberGreen
        DetectionStatus.PROVAVEL -> ElectricBlue
        DetectionStatus.IDENTIFICADO -> CyberAmber
    }

    CyberPanel(glowColor = statusColor) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${variable.name} (${variable.category})",
                    style = MaterialTheme.typography.titleMedium,
                    color = PureWhite,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Origem: ${variable.origin.label}",
                    style = MaterialTheme.typography.labelSmall,
                    color = ElectricBlue
                )
            }
            StatusPill(label = variable.status.label.uppercase(), color = statusColor)
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "Confiança: ${variable.confidencePercent}%",
                style = MaterialTheme.typography.labelMedium,
                color = statusColor
            )
            Spacer(modifier = Modifier.width(10.dp))
            LinearProgressIndicator(
                progress = { variable.confidencePercent / 100f },
                color = statusColor,
                trackColor = CyberOutline,
                modifier = Modifier
                    .weight(1f)
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text("Localização: ${variable.technicalLocation}", style = MaterialTheme.typography.bodySmall, color = PureWhite)
        Text("Tipo: ${variable.dataType}", style = MaterialTheme.typography.bodySmall, color = MutedSilver)
        Text("Evidência: ${variable.evidence}", style = MaterialTheme.typography.labelMedium, color = ElectricBlue)
        Spacer(modifier = Modifier.height(4.dp))
        Text(variable.epistemicNote, style = MaterialTheme.typography.bodySmall, color = MutedSilver)
    }
}

@Composable
private fun OnlineLimitationCard(limitation: OnlineLimitation) {
    val severityColor = when (limitation.severity) {
        "ALTA" -> CyberRed
        "MEDIA" -> CyberAmber
        else -> CyberGreen
    }
    CyberPanel(glowColor = severityColor) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = limitation.title,
                style = MaterialTheme.typography.titleSmall,
                color = PureWhite,
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(8.dp))
            StatusPill(label = "RISCO ${limitation.severity}", color = severityColor)
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text("Evidência: ${limitation.evidence}", style = MaterialTheme.typography.labelMedium, color = ElectricBlue)
        Spacer(modifier = Modifier.height(4.dp))
        Text(limitation.explanation, style = MaterialTheme.typography.bodySmall, color = PureWhite)
        Spacer(modifier = Modifier.height(4.dp))
        Text(limitation.officialApiNote, style = MaterialTheme.typography.bodySmall, color = MutedSilver)
    }
}
