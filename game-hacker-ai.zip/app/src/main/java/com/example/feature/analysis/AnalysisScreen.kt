package com.example.feature.analysis

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.Formatters
import com.example.domain.AnalysisStep
import com.example.domain.GameRecord
import com.example.domain.UiState
import com.example.feature.components.AppIconThumbnail
import com.example.feature.components.CyberPanel
import com.example.feature.components.SectionHeader
import com.example.feature.components.StatusPill
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberOutline
import com.example.ui.theme.CyberRed
import com.example.ui.theme.DeepBlack
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.MutedSilver
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonPurpleBright
import com.example.ui.theme.PureWhite

@Composable
fun AnalysisScreen(
    viewModel: AnalysisViewModel
) {
    val libraryGames by viewModel.libraryGames.collectAsStateWithLifecycle()
    val steps by viewModel.steps.collectAsStateWithLifecycle()
    val reportState by viewModel.reportState.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()

    var pendingDeleteGame by remember { mutableStateOf<GameRecord?>(null) }
    var inspectedGameDetail by remember { mutableStateOf<GameRecord?>(null) }

    val apkPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            viewModel.importAndAnalyzeUri(uri)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 920.dp)
                .align(Alignment.TopCenter)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SectionHeader(
                    title = "GAME AI ENGINE & BIBLIOTECA",
                    subtitle = "Análise estática real de APKs e interpretação estruturada",
                    trailing = {
                        Button(
                            onClick = {
                                apkPickerLauncher.launch(
                                    arrayOf("application/vnd.android.package-archive", "*/*")
                                )
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ElectricBlue,
                                contentColor = DeepBlack
                            ),
                            modifier = Modifier.testTag("btn_import_analyze_apk")
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Importar APK", style = MaterialTheme.typography.labelLarge)
                        }
                    }
                )
            }

            if (statusBanner != null) {
                item {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = ElectricBlue.copy(alpha = 0.14f),
                        border = BorderStroke(1.dp, ElectricBlue.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(statusBanner.orEmpty(), style = MaterialTheme.typography.bodySmall, color = PureWhite, modifier = Modifier.weight(1f))
                            TextButton(onClick = viewModel::clearBanner) { Text("OK") }
                        }
                    }
                }
            }

            if (steps.isNotEmpty() && reportState is UiState.Loading) {
                item {
                    PipelineProgressPanel(steps = steps)
                }
            }

            when (val rState = reportState) {
                is UiState.Loading -> {
                    if (steps.isEmpty()) {
                        item {
                            CyberPanel(glowColor = ElectricBlue) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    CircularProgressIndicator(modifier = Modifier.size(22.dp), color = ElectricBlue)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(rState.message, color = PureWhite)
                                }
                            }
                        }
                    }
                }
                is UiState.Error -> {
                    item {
                        CyberPanel(glowColor = CyberRed) {
                            Text("Falha na Análise", style = MaterialTheme.typography.titleMedium, color = CyberRed)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(rState.message, style = MaterialTheme.typography.bodyMedium, color = PureWhite)
                        }
                    }
                }
                is UiState.Success -> {
                    item {
                        AnalysisReportContent(report = rState.data)
                    }
                }
                UiState.Idle -> Unit
            }

            item {
                SectionHeader(
                    title = "BIBLIOTECA DE APKS (${libraryGames.size})",
                    subtitle = "Armazenamento persistente Room • Remoção segura preserva arquivos originais"
                )
            }

            if (libraryGames.isEmpty()) {
                item {
                    CyberPanel(glowColor = NeonPurple) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.AutoAwesome,
                                contentDescription = "Biblioteca vazia",
                                tint = NeonPurpleBright,
                                modifier = Modifier.size(40.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Nenhum APK importado na biblioteca ainda.",
                                style = MaterialTheme.typography.titleSmall,
                                color = PureWhite
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Toque em 'Importar APK' ou 'ADICIONAR APK' no início para validar e analisar um arquivo real.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MutedSilver
                            )
                        }
                    }
                }
            } else {
                items(libraryGames.size) { idx ->
                    val game = libraryGames[idx]
                    LibraryGameCard(
                        game = game,
                        onOpenDetail = { inspectedGameDetail = game },
                        onAnalyze = { viewModel.analyzeGame(game) },
                        onOpenLastReport = {
                            game.lastAnalysisId?.let { viewModel.openSavedReport(it) }
                        },
                        onRemove = { pendingDeleteGame = game }
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }

    pendingDeleteGame?.let { target ->
        AlertDialog(
            onDismissRequest = { pendingDeleteGame = null },
            title = { Text("Remover da biblioteca?") },
            text = {
                Text(
                    "Remover '${target.name}' da biblioteca interna? O arquivo APK original no armazenamento do usuário não será apagado."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.removeFromLibrary(target.id, deleteCachedCopy = true)
                        pendingDeleteGame = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberRed, contentColor = PureWhite)
                ) {
                    Text("Remover")
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingDeleteGame = null }) {
                    Text("Cancelar")
                }
            }
        )
    }

    inspectedGameDetail?.let { game ->
        AlertDialog(
            onDismissRequest = { inspectedGameDetail = null },
            title = { Text(game.name) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Pacote: ${game.packageName}", style = MaterialTheme.typography.bodySmall)
                    Text("Versão: ${game.versionName} (${game.versionCode})", style = MaterialTheme.typography.bodySmall)
                    Text("Tamanho: ${Formatters.formatFileSize(game.sizeBytes)}", style = MaterialTheme.typography.bodySmall)
                    Text("Importado em: ${Formatters.formatDateTime(game.importedAt)}", style = MaterialTheme.typography.bodySmall)
                    Text("Estado: ${game.analysisStatus.label}", style = MaterialTheme.typography.bodySmall)
                    Text("SHA-256: ${game.sha256}", style = MaterialTheme.typography.labelSmall, color = ElectricBlue)
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.analyzeGame(game)
                    inspectedGameDetail = null
                }) {
                    Text("Analisar agora")
                }
            },
            dismissButton = {
                TextButton(onClick = { inspectedGameDetail = null }) {
                    Text("Fechar")
                }
            }
        )
    }
}

@Composable
private fun PipelineProgressPanel(steps: List<AnalysisStep>) {
    CyberPanel(glowColor = ElectricBlue, elevated = true) {
        Text(
            text = "PIPELINE DE ANÁLISE EM EXECUÇÃO",
            style = MaterialTheme.typography.labelLarge,
            color = ElectricBlue
        )
        Spacer(modifier = Modifier.height(10.dp))
        steps.forEach { step ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                when {
                    step.completed -> Icon(
                        Icons.Rounded.CheckCircle,
                        contentDescription = "Concluído",
                        tint = CyberGreen,
                        modifier = Modifier.size(18.dp)
                    )
                    step.active -> CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        color = ElectricBlue,
                        strokeWidth = 2.dp
                    )
                    else -> Icon(
                        Icons.Rounded.RadioButtonUnchecked,
                        contentDescription = "Pendente",
                        tint = CyberOutline,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${step.index + 1}. ${step.title}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (step.completed || step.active) PureWhite else MutedSilver
                    )
                    if (step.detail.isNotBlank()) {
                        Text(
                            text = step.detail,
                            style = MaterialTheme.typography.labelSmall,
                            color = ElectricBlue
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LibraryGameCard(
    game: GameRecord,
    onOpenDetail: () -> Unit,
    onAnalyze: () -> Unit,
    onOpenLastReport: () -> Unit,
    onRemove: () -> Unit
) {
    CyberPanel(glowColor = NeonPurple) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AppIconThumbnail(
                iconPath = game.iconPath,
                contentDescription = "Ícone de ${game.name}"
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = game.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = PureWhite,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${game.packageName} • v${game.versionName}",
                    style = MaterialTheme.typography.labelMedium,
                    color = ElectricBlue,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${Formatters.formatFileSize(game.sizeBytes)} • ${Formatters.formatDateTime(game.importedAt)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MutedSilver
                )
            }
            StatusPill(
                label = game.analysisStatus.label,
                color = if (game.analysisStatus.name == "COMPLETED") CyberGreen else NeonPurpleBright
            )
        }

        if (!game.lastReportSummary.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Último resultado: ${game.lastReportSummary}",
                style = MaterialTheme.typography.labelSmall,
                color = CyberGreen
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = onAnalyze,
                colors = ButtonDefaults.buttonColors(containerColor = NeonPurple, contentColor = PureWhite),
                modifier = Modifier.testTag("btn_analyze_game_${game.id}")
            ) {
                Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Analisar", style = MaterialTheme.typography.labelLarge)
            }

            OutlinedButton(onClick = onOpenDetail) {
                Text("Abrir", style = MaterialTheme.typography.labelMedium)
            }

            if (game.lastAnalysisId != null) {
                OutlinedButton(onClick = onOpenLastReport) {
                    Text("Relatório", style = MaterialTheme.typography.labelMedium)
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            IconButton(
                onClick = onRemove,
                modifier = Modifier.testTag("btn_remove_game_${game.id}")
            ) {
                Icon(
                    imageVector = Icons.Rounded.DeleteOutline,
                    contentDescription = "Remover ${game.name} da biblioteca",
                    tint = CyberRed
                )
            }
        }
    }
}
