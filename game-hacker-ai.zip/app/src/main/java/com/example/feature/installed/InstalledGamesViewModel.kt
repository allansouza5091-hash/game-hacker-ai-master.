package com.example.feature.installed

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.AppContainer
import com.example.data.InstalledGamesRepository
import com.example.domain.InstalledAppInfo
import com.example.domain.UiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class InstalledFilter(val label: String) {
    ALL("Todos"),
    GAMES_ONLY("Somente Jogos"),
    USER_APPS("Apps de Usuário")
}

class InstalledGamesViewModel(
    private val repository: InstalledGamesRepository
) : ViewModel() {

    private val _appsState = MutableStateFlow<UiState<List<InstalledAppInfo>>>(UiState.Loading("Consultando PackageManager..."))
    val appsState: StateFlow<UiState<List<InstalledAppInfo>>> = _appsState.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _filter = MutableStateFlow(InstalledFilter.ALL)
    val filter: StateFlow<InstalledFilter> = _filter.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _appsState.value = UiState.Loading("Carregando aplicativos visíveis no dispositivo...")
            runCatching {
                repository.loadVisibleInstalledApps()
            }.fold(
                onSuccess = { list ->
                    _appsState.value = UiState.Success(list)
                },
                onFailure = { err ->
                    _appsState.value = UiState.Error(
                        err.localizedMessage ?: "Falha ao consultar pacotes instalados."
                    )
                }
            )
        }
    }

    fun updateQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateFilter(filter: InstalledFilter) {
        _filter.value = filter
    }

    class Factory(private val container: AppContainer) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return InstalledGamesViewModel(container.installedGamesRepository) as T
        }
    }
}
