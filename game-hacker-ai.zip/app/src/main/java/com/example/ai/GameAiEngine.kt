package com.example.ai

import com.example.domain.AiInterpretationResult
import com.example.domain.ApkTechnicalMetadata
import com.example.domain.DetectionStatus
import com.example.domain.DetectedVariable
import com.example.domain.OnlineLimitation

interface GameAiEngine {
    val engineLabel: String
    val isCloudConfigured: Boolean

    suspend fun interpretTechnicalData(
        metadata: ApkTechnicalMetadata,
        variables: List<DetectedVariable>,
        limitations: List<OnlineLimitation>
    ): AiInterpretationResult
}

class LocalTechnicalGameAiEngine : GameAiEngine {
    override val engineLabel: String = "Local Técnico (Firebase AI desativado)"
    override val isCloudConfigured: Boolean = false

    override suspend fun interpretTechnicalData(
        metadata: ApkTechnicalMetadata,
        variables: List<DetectedVariable>,
        limitations: List<OnlineLimitation>
    ): AiInterpretationResult {
        val confirmedCount = variables.count { it.status == DetectionStatus.CONFIRMADO }
        val probableCount = variables.count { it.status == DetectionStatus.PROVAVEL }
        val identifiedCount = variables.count { it.status == DetectionStatus.IDENTIFICADO }

        val abiSummary = if (metadata.nativeAbis.isEmpty()) {
            "somente bytecode Dalvik/ART (sem bibliotecas nativas .so)"
        } else {
            "arquiteturas nativas ${metadata.nativeAbis.joinToString(", ")}"
        }

        val summary = buildString {
            append("Análise técnica de ${metadata.appName} (${metadata.packageName} v${metadata.versionName}). ")
            append("Foram examinadas ${metadata.entryCount} entradas no pacote (${metadata.dexFiles.size} arquivo(s) DEX, ")
            append("${metadata.configFiles.size} arquivo(s) de configuração). ")
            append("Detecção de referências: $confirmedCount confirmada(s) em config, ")
            append("$probableCount provável(is) em código DEX e $identifiedCount identificada(s) em recursos/UI.")
        }

        val architectureAssessment = buildString {
            append("Estrutura: $abiSummary. ")
            append("Componentes declarados: ${metadata.activitiesCount} Activities, ")
            append("${metadata.servicesCount} Services, ${metadata.receiversCount} Receivers. ")
            if (metadata.isDebuggable) {
                append("Flag android:debuggable ativa (comum em builds próprios de desenvolvimento/teste). ")
            } else {
                append("Build de produção (debuggable=false). ")
            }
            if (metadata.configFiles.isNotEmpty()) {
                append("Arquivos de dados encontrados: ${metadata.configFiles.take(4).joinToString(", ")}.")
            }
        }

        val onlineSummary = if (metadata.hasOnlinePermissions || limitations.any { it.severity == "ALTA" }) {
            "O pacote apresenta restrições online significativas (${limitations.count { it.severity == "ALTA" }} alerta(s) crítico(s)). " +
                "Variáveis de economia ou placar sincronizadas com servidor não podem ser modificadas localmente."
        } else {
            "Poucos indicadores de rede nos metadados estáticos. Mesmo assim, alterações são permitidas apenas em jogos próprios ou autorizados."
        }

        val recommendations = buildList {
            if (confirmedCount > 0) {
                add("Validar as chaves JSON confirmadas nos assets apenas se o projeto for próprio ou possuir autorização expressa.")
            }
            if (probableCount > 0 && confirmedCount == 0) {
                add("Os símbolos DEX encontrados indicam possíveis campos de lógica; eles não representam valores ativos em memória.")
            }
            if (identifiedCount > 0) {
                add("Referências apenas em UI/strings foram rebaixadas para 'Identificado' para evitar falsos positivos.")
            }
            if (metadata.hasOnlinePermissions) {
                add("Para jogos online, utilizar exclusivamente integrações e APIs oficiais do desenvolvedor.")
            }
            add("Para interpretação generativa avançada por LLM, habilite o Firebase AI Logic nas configurações do projeto.")
        }

        return AiInterpretationResult(
            engineMode = "LOCAL_TECHNICAL_FALLBACK",
            isCloudAiActive = false,
            noticeBanner = "IA em nuvem (Gemini) requer Firebase AI Logic. Exibindo interpretação técnica local determinística baseada exclusivamente nos dados reais extraídos.",
            summary = summary,
            architectureAssessment = architectureAssessment,
            onlineRestrictionsSummary = onlineSummary,
            recommendations = recommendations
        )
    }
}
