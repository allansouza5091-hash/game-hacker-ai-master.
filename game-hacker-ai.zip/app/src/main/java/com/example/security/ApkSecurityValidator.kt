package com.example.security

import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import java.util.zip.ZipFile

sealed interface ApkValidationResult {
    data class Valid(
        val sizeBytes: Long,
        val sha256: String,
        val entryCount: Int,
        val hasManifest: Boolean,
        val dexCount: Int,
        val warnings: List<String>
    ) : ApkValidationResult

    data class Invalid(
        val reason: String
    ) : ApkValidationResult
}

class ApkSecurityValidator {

    fun validateApkFile(
        file: File,
        maxSizeBytes: Long = DEFAULT_MAX_APK_BYTES,
        maxEntries: Int = DEFAULT_MAX_ZIP_ENTRIES
    ): ApkValidationResult {
        if (!file.exists() || !file.isFile) {
            return ApkValidationResult.Invalid("Arquivo APK não encontrado no armazenamento interno.")
        }

        val sizeBytes = file.length()
        if (sizeBytes < MIN_ZIP_SIZE_BYTES) {
            return ApkValidationResult.Invalid("Arquivo muito pequeno ($sizeBytes bytes) para ser um APK válido.")
        }
        if (sizeBytes > maxSizeBytes) {
            val maxMb = maxSizeBytes / (1024 * 1024)
            return ApkValidationResult.Invalid("Arquivo excede o limite de segurança configurado (${maxMb} MB).")
        }

        val magic = ByteArray(4)
        FileInputStream(file).use { fis ->
            val read = fis.read(magic)
            if (read < 4 ||
                magic[0] != 0x50.toByte() ||
                magic[1] != 0x4B.toByte() ||
                magic[2] != 0x03.toByte() ||
                magic[3] != 0x04.toByte()
            ) {
                return ApkValidationResult.Invalid("Assinatura binária inválida: o arquivo não possui cabeçalho ZIP/APK (PK).")
            }
        }

        val warnings = mutableListOf<String>()
        var entryCount = 0
        var hasManifest = false
        var dexCount = 0

        try {
            ZipFile(file).use { zip ->
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val entry = entries.nextElement()
                    entryCount++
                    if (entryCount > maxEntries) {
                        return ApkValidationResult.Invalid(
                            "Limite de entradas ZIP excedido (>$maxEntries). Proteção contra ZIP bomb ativada."
                        )
                    }
                    val name = entry.name
                    if (name.contains("..") || name.startsWith("/") || name.startsWith("\\")) {
                        return ApkValidationResult.Invalid(
                            "Caminho inseguro detectado dentro do arquivo ($name). Proteção ZipSlip ativada."
                        )
                    }
                    if (name == "AndroidManifest.xml") {
                        hasManifest = true
                    }
                    if (name.startsWith("classes") && name.endsWith(".dex")) {
                        dexCount++
                    }
                }
            }
        } catch (e: Exception) {
            return ApkValidationResult.Invalid("Arquivo ZIP/APK corrompido ou ilegível: ${e.localizedMessage ?: "erro desconhecido"}")
        }

        if (!hasManifest) {
            return ApkValidationResult.Invalid("O arquivo ZIP selecionado não contém AndroidManifest.xml. Não é um APK Android válido.")
        }
        if (dexCount == 0) {
            warnings.add("Nenhum arquivo classes.dex detectado (possível APK de recursos/split ou binário nativo).")
        }

        val sha256 = computeSha256(file)
        return ApkValidationResult.Valid(
            sizeBytes = sizeBytes,
            sha256 = sha256,
            entryCount = entryCount,
            hasManifest = hasManifest,
            dexCount = dexCount,
            warnings = warnings
        )
    }

    fun computeSha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(8192)
        FileInputStream(file).use { input ->
            var bytesRead = input.read(buffer)
            while (bytesRead != -1) {
                digest.update(buffer, 0, bytesRead)
                bytesRead = input.read(buffer)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    companion object {
        const val MIN_ZIP_SIZE_BYTES = 22L
        const val DEFAULT_MAX_APK_BYTES = 250L * 1024L * 1024L
        const val DEFAULT_MAX_ZIP_ENTRIES = 10_000
    }
}
